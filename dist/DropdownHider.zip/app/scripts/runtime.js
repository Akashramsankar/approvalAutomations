let client;

const EVENT_CONFIG = [
  { eventName: "ticket.statusChanged", fieldId: "status" },
  { eventName: "ticket.priorityChanged", fieldId: "priority" },
  { eventName: "ticket.typeChanged", fieldId: "ticket_type" },
  { eventName: "ticket.groupChanged", fieldId: "group" },
  { eventName: "ticket.agentChanged", fieldId: "agent" },
];

const runtimeState = {
  rules: [],
  fieldCatalog: {},
  triggerFieldCatalog: {},
  lastConfigRefreshAt: 0,
  liveFieldOptions: {},
  currentValues: {
    status: null,
    priority: null,
    ticket_type: null,
    group: null,
    agent: null,
    source: null,
  },
  customFieldValues: {},
  fieldEventTimestamps: {},
  lastApplied: {},
  lastFailedOptions: {},
  optionPayloadPreferences: {},
  applyDebounceTimer: null,
  applyInFlight: false,
  applyQueued: false,
  applyWaiters: [],
  detailsRefreshTimer: null,
  detailsRefreshQueued: false,
  detailsRefreshWaiters: [],
  isDetailsPage: false,
  refreshingDetails: false,
};

const RUNTIME_CACHE_KEY = "dhp_runtime_cache_v3";
const CONFIG_REFRESH_INTERVAL_MS = 5000;
const APPLY_RULES_DEBOUNCE_MS = 80;
const DETAILS_REFRESH_DEBOUNCE_MS = 120;
const RECENT_EVENT_VALUE_GRACE_MS = 2000;
const FAILED_PAYLOAD_RETRY_COOLDOWN_MS = 1500;
const DEBUG_STORAGE_KEY = "dhp_debug";
const DEBUG_NAMESPACE = "[Dropdown Hider Pro]";
const DEBUG_HISTORY_LIMIT = 200;

document.addEventListener("DOMContentLoaded", initRuntime);

async function initRuntime() {
  try {
    debugLog("init:start");
    client = await app.initialized();
    await detectContext();

    const cached = loadCachedRuntimeData();
    if (cached) {
      runtimeState.rules = cached.rules;
      runtimeState.fieldCatalog = cached.field_catalog;
      runtimeState.triggerFieldCatalog = cached.trigger_field_catalog || {};
      runtimeState.liveFieldOptions = {};
      debugLog("init:cached-runtime-loaded", {
        rules: runtimeState.rules.length,
        fields: Object.keys(runtimeState.fieldCatalog).length,
      });
      await requestApplyRules("init:cached-runtime", { immediate: true });
    }

    await refreshRuntimeConfig(true);
    bindRuntimeEvents();
    await requestApplyRules("init:fresh-runtime", { immediate: true });
    cacheRuntimeData();
    debugLog("init:complete", {
      isDetailsPage: runtimeState.isDetailsPage,
      rules: runtimeState.rules.length,
    });
  } catch (error) {
    debugLog("init:error", { message: error && error.message });
    console.error("Failed to initialize Dropdown Hider Pro runtime:", error);
  }
}

function loadCachedRuntimeData() {
  try {
    const raw = localStorage.getItem(RUNTIME_CACHE_KEY);
    if (!raw) {
      return null;
    }
    const data = JSON.parse(raw);
    if (data && Array.isArray(data.rules) && data.field_catalog) {
      return data;
    }
    return null;
  } catch {
    return null;
  }
}

function cacheRuntimeData() {
  try {
    localStorage.setItem(RUNTIME_CACHE_KEY, JSON.stringify({
      rules: runtimeState.rules,
      field_catalog: runtimeState.fieldCatalog,
      trigger_field_catalog: runtimeState.triggerFieldCatalog,
    }));
  } catch {
    // Storage may be unavailable; ignore silently.
  }
}

function bindRuntimeEvents() {
  client.events.on("app.activated", async () => {
    debugLog("event:app.activated");
    await refreshRuntimeConfig(true);
    if (runtimeState.isDetailsPage) {
      await requestTicketDetailsRefresh("event:app.activated", { immediate: true });
    }
    await requestApplyRules("event:app.activated", { immediate: true });
    cacheRuntimeData();
  });

  EVENT_CONFIG.forEach((config) => {
    client.events.on(config.eventName, async (payload) => {
      debugLog("event:field-changed", {
        eventName: config.eventName,
        fieldId: config.fieldId,
      });
      await refreshRuntimeConfig();
      await updateValueFromEvent(config.fieldId, payload);
      if (runtimeState.isDetailsPage) {
        await requestTicketDetailsRefresh(`${config.eventName}:details`);
      }
      await requestApplyRules(`event:${config.eventName}`);
    });
  });

  if (runtimeState.isDetailsPage) {
    client.events.on("ticket.propertiesUpdated", async () => {
      debugLog("event:ticket.propertiesUpdated");
      await refreshRuntimeConfig();
      await requestTicketDetailsRefresh("event:ticket.propertiesUpdated");
      await requestApplyRules("event:ticket.propertiesUpdated");
    });
  }
}

async function loadRuntimeData() {
  const response = await client.request.invoke("getDropdownHiderRuntimeData", {});
  const payload = parseInvokeResponse(response);

  if (!payload || payload.success === false) {
    throw new Error(resolveInvokeError(payload) || "Unable to load runtime data.");
  }

  runtimeState.rules = Array.isArray(payload.rules) ? payload.rules : [];
  runtimeState.fieldCatalog = payload.field_catalog || {};
  runtimeState.triggerFieldCatalog = payload.trigger_field_catalog || {};
  runtimeState.liveFieldOptions = {};
  runtimeState.lastFailedOptions = {};
  runtimeState.lastConfigRefreshAt = Date.now();
  debugLog("runtime-data:loaded", {
    rules: runtimeState.rules.length,
    fieldCatalogKeys: Object.keys(runtimeState.fieldCatalog),
    triggerFieldKeys: Object.keys(runtimeState.triggerFieldCatalog),
  });
}

async function refreshRuntimeConfig(force) {
  const shouldForce = Boolean(force);
  const now = Date.now();

  if (!shouldForce && now - runtimeState.lastConfigRefreshAt < CONFIG_REFRESH_INTERVAL_MS) {
    return;
  }

  await loadRuntimeData();
}

async function detectContext() {
  try {
    const result = await client.data.get("ticket");
    const ticket = result && result.ticket ? result.ticket : result;
    if (ticket && typeof ticket === "object") {
      runtimeState.isDetailsPage = true;
      updateTicketSnapshot(ticket);
      debugLog("context:details-page-detected");
      return;
    }
  } catch {
    runtimeState.isDetailsPage = false;
  }

  debugLog("context:new-ticket-page-detected");
}

function requestTicketDetailsRefresh(reason, options) {
  if (!runtimeState.isDetailsPage) {
    return Promise.resolve();
  }

  const immediate = Boolean(options && options.immediate);

  return new Promise((resolve) => {
    runtimeState.detailsRefreshWaiters.push(resolve);
    runtimeState.detailsRefreshQueued = true;

    if (runtimeState.detailsRefreshTimer) {
      window.clearTimeout(runtimeState.detailsRefreshTimer);
      runtimeState.detailsRefreshTimer = null;
    }

    const delay = immediate ? 0 : DETAILS_REFRESH_DEBOUNCE_MS;
    debugLog("ticket:details-refresh-requested", { reason, immediate, delay });

    runtimeState.detailsRefreshTimer = window.setTimeout(() => {
      runtimeState.detailsRefreshTimer = null;
      void flushTicketDetailsRefresh(reason);
    }, delay);
  });
}

async function flushTicketDetailsRefresh(reason) {
  if (runtimeState.refreshingDetails) {
    debugLog("ticket:details-refresh-deferred", { reason });
    return;
  }

  runtimeState.refreshingDetails = true;
  runtimeState.detailsRefreshQueued = false;
  const waiters = runtimeState.detailsRefreshWaiters.splice(0);

  try {
    debugLog("ticket:details-refresh-start", { reason });
    await performTicketDetailsRefresh();
    waiters.forEach((resolve) => resolve());
    debugLog("ticket:details-refresh-complete", { reason });
  } catch (error) {
    waiters.forEach((resolve) => resolve());
    debugLog("ticket:details-refresh-failed", { message: error && error.message });
    console.error("Unable to refresh ticket details:", error);
  } finally {
    runtimeState.refreshingDetails = false;

    if (runtimeState.detailsRefreshQueued) {
      debugLog("ticket:details-refresh-requeued", { reason });
      void requestTicketDetailsRefresh("ticket:details-refresh-requeued", { immediate: true });
    }
  }
}

async function performTicketDetailsRefresh() {
  const result = await client.data.get("ticket");
  const ticket = result && result.ticket ? result.ticket : result;
  if (ticket && typeof ticket === "object") {
    updateTicketSnapshot(ticket);
    debugLog("ticket:details-refreshed", {
      currentValues: runtimeState.currentValues,
    });
  }
}

function updateTicketSnapshot(ticket) {
  updateCurrentValueFromSnapshot("status", extractObjectValue("status", ticket));
  updateCurrentValueFromSnapshot("priority", extractObjectValue("priority", ticket));
  updateCurrentValueFromSnapshot("ticket_type", extractObjectValue("ticket_type", ticket));
  updateCurrentValueFromSnapshot("group", extractObjectValue("group", ticket));
  updateCurrentValueFromSnapshot("agent", extractObjectValue("agent", ticket));
  updateCurrentValueFromSnapshot("source", extractObjectValue("source", ticket));
  runtimeState.customFieldValues = normalizeCustomFields(ticket.custom_fields || ticket.customFields || {});
  debugLog("ticket:snapshot-updated", {
    currentValues: runtimeState.currentValues,
    customFieldKeys: Object.keys(runtimeState.customFieldValues || {}),
  });
}

async function updateValueFromEvent(fieldId, payload) {
  const value = await extractEventValue(fieldId, payload);
  if (value !== null) {
    runtimeState.currentValues[fieldId] = normalizeTriggerValue(fieldId, value);
    runtimeState.fieldEventTimestamps[fieldId] = Date.now();
    debugLog("ticket:event-value-updated", {
      fieldId,
      rawValue: value,
      normalizedValue: runtimeState.currentValues[fieldId],
    });
  }
}

function updateCurrentValueFromSnapshot(fieldId, rawValue) {
  const normalizedValue = normalizeTriggerValue(fieldId, rawValue);
  const lastEventTimestamp = runtimeState.fieldEventTimestamps[fieldId] || 0;
  const shouldPreserveEventValue =
    lastEventTimestamp &&
    Date.now() - lastEventTimestamp < RECENT_EVENT_VALUE_GRACE_MS &&
    runtimeState.currentValues[fieldId] !== null &&
    runtimeState.currentValues[fieldId] !== undefined &&
    runtimeState.currentValues[fieldId] !== "";

  if (shouldPreserveEventValue) {
    debugLog("ticket:snapshot-value-skipped", {
      fieldId,
      snapshotValue: normalizedValue,
      eventValue: runtimeState.currentValues[fieldId],
      lastEventTimestamp,
    });
    return;
  }

  runtimeState.currentValues[fieldId] = normalizedValue;
}

async function extractEventValue(fieldId, payload) {
  const source = payload && payload.helper && typeof payload.helper.getData === "function"
    ? await payload.helper.getData()
    : payload;

  return extractObjectValue(fieldId, source);
}

function requestApplyRules(reason, options) {
  const immediate = Boolean(options && options.immediate);

  return new Promise((resolve) => {
    runtimeState.applyWaiters.push(resolve);
    runtimeState.applyQueued = true;

    if (runtimeState.applyDebounceTimer) {
      window.clearTimeout(runtimeState.applyDebounceTimer);
      runtimeState.applyDebounceTimer = null;
    }

    const delay = immediate ? 0 : APPLY_RULES_DEBOUNCE_MS;
    debugLog("rules:apply-requested", { reason, immediate, delay });

    runtimeState.applyDebounceTimer = window.setTimeout(() => {
      runtimeState.applyDebounceTimer = null;
      void flushApplyRules(reason);
    }, delay);
  });
}

async function flushApplyRules(reason) {
  if (runtimeState.applyInFlight) {
    debugLog("rules:apply-flush-deferred", { reason });
    return;
  }

  runtimeState.applyInFlight = true;
  runtimeState.applyQueued = false;
  const waiters = runtimeState.applyWaiters.splice(0);

  try {
    debugLog("rules:apply-flush-start", { reason });
    await applyRules(reason);
    waiters.forEach((resolve) => resolve());
    debugLog("rules:apply-flush-complete", { reason });
  } catch (error) {
    debugLog("rules:apply-flush-failed", {
      reason,
      message: error && error.message,
    });
    waiters.forEach((resolve) => resolve());
  } finally {
    runtimeState.applyInFlight = false;

    if (runtimeState.applyQueued) {
      debugLog("rules:apply-requeued", { reason });
      void requestApplyRules("flush:requeued", { immediate: true });
    }
  }
}

async function applyRules(reason) {
  const evaluations = evaluateRules();
  const hiddenMap = buildHiddenMap(evaluations);
  const targetFieldNames = new Set(Object.keys(runtimeState.lastApplied || {}));

  runtimeState.rules.forEach((rule) => {
    (rule.hidden_selections || []).forEach((selection) => {
      if (selection.field_name) {
        targetFieldNames.add(selection.field_name);
      }
    });
  });

  const tasks = [];
  const fieldOutcomes = [];
  debugLog("rules:apply-start", {
    reason,
    hiddenMap,
    targetFields: Array.from(targetFieldNames),
  });

  for (const fieldName of targetFieldNames) {
    const fieldMeta = runtimeState.fieldCatalog[fieldName];
    if (!fieldMeta || !fieldMeta.element_id) {
      fieldOutcomes.push({
        fieldName,
        status: "missing-meta",
      });
      continue;
    }

    const availableOptions = await resolveAvailableOptions(fieldName, fieldMeta);
    if (!availableOptions.length) {
      fieldOutcomes.push({
        fieldName,
        status: "no-options",
      });
      continue;
    }

    const hiddenValues = hiddenMap[fieldName] || [];
    const currentValue = runtimeState.currentValues[fieldName];
    const filteredOptions = availableOptions
      .filter((option) => {
        const shouldHide = hiddenValues.some((hiddenValue) => optionMatchesHiddenValue(fieldMeta, option, hiddenValue));
        if (!shouldHide) {
          return true;
        }

        // Freshdesk rejects status payloads when the currently selected value disappears.
        if (fieldMeta.element_id === "status" && optionMatchesCurrentValue(fieldMeta, option, currentValue)) {
          debugLog("field:status-option-preserved", {
            fieldName,
            currentValue,
            option,
          });
          return true;
        }

        return false;
      });
    const payloadCandidates = buildOptionPayloadCandidates(fieldName, fieldMeta, filteredOptions);
    const nextOptions = payloadCandidates[0] ? payloadCandidates[0].values : [];
    const nextOptionsKey = serializeOptions(nextOptions);

    logStatusConsole("payload-built", {
      fieldName,
      currentValue,
      hiddenValues,
      availableOptions: summarizeOptionsForConsole(availableOptions),
      filteredOptions: summarizeOptionsForConsole(filteredOptions),
      payloadCandidates,
    }, fieldMeta);

    if (arraysMatch(runtimeState.lastApplied[fieldName], nextOptions)) {
      debugLog("rules:apply-skip-unchanged", { fieldName, nextOptions });
      fieldOutcomes.push({
        fieldName,
        status: "unchanged",
        hiddenValues,
      });
      continue;
    }

    if (shouldSkipFailedPayload(fieldName, nextOptionsKey)) {
      debugLog("rules:apply-skip-failed-payload", {
        fieldName,
        nextOptions,
        retryAfterMs: getFailedPayloadRetryAfter(fieldName),
      });
      fieldOutcomes.push({
        fieldName,
        status: "skipped-failed-payload",
        hiddenValues,
        options: nextOptions,
      });
      continue;
    }

    tasks.push(
      applyFieldOptions(fieldName, fieldMeta, payloadCandidates, hiddenValues).then((result) => {
        fieldOutcomes.push(result);
      })
    );
  }

  await Promise.all(tasks);
  reportApplyOutcome(reason, evaluations, hiddenMap, fieldOutcomes);
  debugLog("rules:apply-complete", {
    reason,
    appliedFields: Object.keys(runtimeState.lastApplied),
    fieldOutcomes,
  });
}

function evaluateRules() {
  return runtimeState.rules.map((rule) => {
    const conditionOperator = normalizeConditionOperator(rule && rule.condition_operator);
    const active = rule.active !== false;
    const conditionResult = active
      ? evaluateConditions(rule.conditions, rule, conditionOperator)
      : {
        matched: false,
        hasConditions: Array.isArray(rule.conditions) && rule.conditions.length > 0,
        conditions: [],
        operator: conditionOperator,
      };

    debugLog("rule:evaluated", {
      ruleId: rule.id,
      ruleName: rule.name,
      active,
      conditionOperator,
      matched: active && conditionResult.matched,
    });

    return {
      rule,
      active,
      conditionOperator,
      matched: active && conditionResult.matched,
      hasConditions: conditionResult.hasConditions,
      conditions: conditionResult.conditions,
    };
  });
}

function buildHiddenMap(evaluations) {
  const hiddenMap = {};

  (Array.isArray(evaluations) ? evaluations : []).forEach((evaluation) => {
    if (!evaluation || !evaluation.matched || !evaluation.rule) {
      return;
    }

    (evaluation.rule.hidden_selections || []).forEach((selection) => {
      if (!selection.field_name) {
        return;
      }

      if (!hiddenMap[selection.field_name]) {
        hiddenMap[selection.field_name] = [];
      }

      (selection.hidden_values || []).forEach((value) => {
        if (!hiddenMap[selection.field_name].some((item) => normalizeValue(item) === normalizeValue(value))) {
          hiddenMap[selection.field_name].push(value);
        }
      });
    });
  });

  debugLog("rules:hidden-map-built", hiddenMap);
  return hiddenMap;
}

function evaluateConditions(conditions, rule, operator) {
  const normalizedOperator = normalizeConditionOperator(operator);
  if (!Array.isArray(conditions) || !conditions.length) {
    debugLog("rule:conditions-none", {
      ruleId: rule && rule.id,
      ruleName: rule && rule.name,
      operator: normalizedOperator,
    });
    return {
      matched: true,
      hasConditions: false,
      operator: normalizedOperator,
      conditions: [],
    };
  }

  const evaluatedConditions = conditions.map((condition) => {
    let currentValue = runtimeState.currentValues[condition.field];
    if (currentValue === null || currentValue === undefined || currentValue === "") {
      currentValue = normalizeTriggerValue(
        condition.field,
        extractObjectValue(condition.field, runtimeState.customFieldValues[condition.field])
      );
    }
    if (currentValue === null || currentValue === "") {
      debugLog("rule:condition-miss-empty", {
        ruleId: rule && rule.id,
        field: condition.field,
        operator: normalizedOperator,
        expected: condition.values || [],
      });
      return {
        field: condition.field,
        expected: condition.values || [],
        currentValue,
        matched: false,
        reason: "empty-current-value",
      };
    }

    const matched = (condition.values || []).some(
      (value) => normalizeValue(value) === normalizeValue(currentValue)
    );

    debugLog("rule:condition-evaluated", {
      ruleId: rule && rule.id,
      field: condition.field,
      operator: normalizedOperator,
      expected: condition.values || [],
      currentValue,
      matched,
    });

    return {
      field: condition.field,
      expected: condition.values || [],
      currentValue,
      matched,
      reason: matched ? "matched" : "value-mismatch",
    };
  });

  return {
    matched: normalizedOperator === "or"
      ? evaluatedConditions.some((condition) => condition.matched)
      : evaluatedConditions.every((condition) => condition.matched),
    hasConditions: true,
    operator: normalizedOperator,
    conditions: evaluatedConditions,
  };
}

async function applyFieldOptions(fieldName, fieldMeta, payloadCandidates, hiddenValues) {
  const candidates = Array.isArray(payloadCandidates) && payloadCandidates.length
    ? payloadCandidates
    : [{ strategy: "submitValue", values: [] }];
  let lastError = null;

  for (let index = 0; index < candidates.length; index += 1) {
    const candidate = candidates[index];
    const options = Array.isArray(candidate && candidate.values) ? candidate.values : [];
    const strategy = candidate && candidate.strategy ? candidate.strategy : "submitValue";

    try {
      debugLog("field:set-options-attempt", {
        fieldName,
        elementId: fieldMeta.element_id,
        strategy,
        attempt: index + 1,
        options,
        hiddenValues,
      });
      logStatusConsole("set-options-attempt", {
        fieldName,
        strategy,
        attempt: index + 1,
        options,
        hiddenValues,
      }, fieldMeta);
      await client.interface.trigger("setOptions", {
        id: fieldMeta.element_id,
        value: options,
      });

      runtimeState.lastApplied[fieldName] = [...options];
      runtimeState.optionPayloadPreferences[fieldName] = strategy;
      delete runtimeState.lastFailedOptions[fieldName];
      debugLog("field:set-options-success", {
        fieldName,
        strategy,
        options,
      });
      logStatusConsole("set-options-success", {
        fieldName,
        strategy,
        options,
      }, fieldMeta);

      const currentValue = runtimeState.customFieldValues[fieldName];
      if (
        runtimeState.isDetailsPage &&
        currentValue &&
        hiddenValues.some((value) => normalizeValue(value) === normalizeValue(currentValue))
      ) {
        debugLog("field:set-value-clear", {
          fieldName,
          elementId: fieldMeta.element_id,
          currentValue,
        });
        await client.interface.trigger("setValue", {
          id: fieldMeta.element_id,
          value: "",
        });
      }

      return {
        fieldName,
        status: "applied",
        hiddenValues,
        options,
        strategy,
      };
    } catch (error) {
      lastError = error;
      debugLog("field:set-options-attempt-failed", {
        fieldName,
        elementId: fieldMeta.element_id,
        strategy,
        attempt: index + 1,
        options,
        message: error && error.message,
      });
      logStatusConsole("set-options-attempt-failed", {
        fieldName,
        strategy,
        attempt: index + 1,
        options,
        hiddenValues,
        message: error && error.message,
        error,
      }, fieldMeta, "warn");
    }
  }

  const primaryOptions = candidates[0] ? candidates[0].values : [];
  runtimeState.lastFailedOptions[fieldName] = {
    key: serializeOptions(primaryOptions),
    failedAt: Date.now(),
  };
  debugLog("field:set-options-failed", {
    fieldName,
    elementId: fieldMeta.element_id,
    payloadCandidates: candidates,
    message: lastError && lastError.message,
    error: lastError,
  });
  logStatusConsole("set-options-failed", {
    fieldName,
    payloadCandidates: candidates,
    hiddenValues,
    message: lastError && lastError.message,
    error: lastError,
  }, fieldMeta, "error");
  console.error(`Unable to update options for ${fieldName}:`, lastError);
  return {
    fieldName,
    status: "failed",
    hiddenValues,
    options: primaryOptions,
    payloadCandidates: candidates.map((candidate) => ({
      strategy: candidate.strategy,
      options: candidate.values,
    })),
    message: lastError && lastError.message,
  };
}

function reportApplyOutcome(reason, evaluations, hiddenMap, fieldOutcomes) {
  if (!shouldLogConditionFailure(reason)) {
    return;
  }

  const relatedRules = (Array.isArray(evaluations) ? evaluations : []).filter((evaluation) => {
    if (!evaluation || !evaluation.active || !evaluation.hasConditions) {
      return false;
    }

    return reason === "event:ticket.propertiesUpdated" ||
      evaluation.conditions.some((condition) => eventReasonMatchesField(reason, condition.field));
  });

  if (!relatedRules.length) {
    return;
  }

  const matchedRules = relatedRules.filter((evaluation) => evaluation.matched);
  if (!matchedRules.length) {
    console.warn(`${DEBUG_NAMESPACE} Condition changed but no rules matched.`, {
      reason,
      currentValues: runtimeState.currentValues,
      rules: relatedRules.map(summarizeRuleEvaluation),
    });
    return;
  }

  const failedFields = (Array.isArray(fieldOutcomes) ? fieldOutcomes : []).filter((outcome) =>
    outcome &&
    ["missing-meta", "no-options", "skipped-failed-payload", "failed"].includes(outcome.status)
  );

  if (failedFields.length) {
    console.warn(`${DEBUG_NAMESPACE} Conditions matched, but hiding could not be fully applied.`, {
      reason,
      hiddenMap,
      matchedRules: matchedRules.map(summarizeRuleEvaluation),
      fieldOutcomes: failedFields,
    });
  }
}

function shouldLogConditionFailure(reason) {
  return typeof reason === "string" && reason.startsWith("event:");
}

function eventReasonMatchesField(reason, fieldId) {
  if (!reason || !fieldId) {
    return false;
  }

  return reason === `event:ticket.${fieldId === "ticket_type" ? "type" : fieldId}Changed` ||
    reason === `event:ticket.${fieldId === "ticket_type" ? "type" : fieldId}Changed:details`;
}

function summarizeRuleEvaluation(evaluation) {
  return {
    ruleId: evaluation.rule && evaluation.rule.id,
    ruleName: evaluation.rule && evaluation.rule.name,
    conditionOperator: evaluation.conditionOperator,
    matched: evaluation.matched,
    conditions: (evaluation.conditions || []).map((condition) => ({
      field: condition.field,
      expected: condition.expected,
      currentValue: condition.currentValue,
      matched: condition.matched,
      reason: condition.reason,
    })),
  };
}

function normalizeConditionOperator(value) {
  return normalizeValue(value) === "or" ? "or" : "and";
}

function normalizeCustomFields(customFields) {
  if (Array.isArray(customFields)) {
    return customFields.reduce((accumulator, item) => {
      if (item && item.name) {
        accumulator[item.name] = extractObjectValue(item.name, item.value);
      }
      return accumulator;
    }, {});
  }

  if (customFields && typeof customFields === "object") {
    return Object.keys(customFields).reduce((accumulator, key) => {
      accumulator[key] = extractObjectValue(key, customFields[key]);
      return accumulator;
    }, {});
  }

  return {};
}

function extractOptionRecords(options) {
  if (!Array.isArray(options)) {
    return [];
  }

  return options
    .map((option) => {
      if (typeof option === "string") {
        return {
          label: option,
          uiValue: option,
          rawValue: option,
          submitValue: option,
        };
      }

      if (option && typeof option === "object") {
        const rawValue = option.value !== undefined && option.value !== null
          ? option.value
          : option.label;
        const uiValue = rawValue;
        const label = option.label !== undefined && option.label !== null
          ? option.label
          : rawValue;

        if (label === "" || uiValue === "" || rawValue === "") {
          return null;
        }

        return {
          label: String(label),
          uiValue,
          rawValue,
          submitValue: rawValue,
        };
      }

      return null;
    })
    .filter(Boolean);
}

async function resolveAvailableOptions(fieldName, fieldMeta) {
  const cachedOptions = runtimeState.liveFieldOptions[fieldName];
  if (Array.isArray(cachedOptions) && cachedOptions.length) {
    return cachedOptions;
  }

  const objectName = buildFieldOptionsObjectName(fieldMeta);
  if (objectName) {
    try {
      const response = await client.data.get(objectName);
      const rawOptions = response && response[objectName];
      const options = mapLiveOptionsToRecords(fieldName, fieldMeta, rawOptions);
      if (options.length) {
        runtimeState.liveFieldOptions[fieldName] = options;
        debugLog("field:options-live", {
          fieldName,
          objectName,
          options,
        });
        return options;
      }
    } catch (error) {
      debugLog("field:options-live-failed", {
        fieldName,
        objectName,
        message: error && error.message,
      });
      console.warn(`Unable to load live options for ${fieldName}:`, error);
    }
  }

  const triggerOptionsFallback = resolveTriggerOptionRecords(fieldName, fieldMeta);
  if (triggerOptionsFallback.length) {
    runtimeState.liveFieldOptions[fieldName] = triggerOptionsFallback;
    debugLog("field:options-trigger-fallback", {
      fieldName,
      options: triggerOptionsFallback,
    });
    return triggerOptionsFallback;
  }

  const fallbackOptions = resolveFieldCatalogOptionRecords(fieldMeta);
  runtimeState.liveFieldOptions[fieldName] = fallbackOptions;
  debugLog("field:options-field-catalog-fallback", {
    fieldName,
    options: fallbackOptions,
  });
  return fallbackOptions;
}

function buildFieldOptionsObjectName(fieldMeta) {
  const elementId = fieldMeta && fieldMeta.element_id;
  if (!elementId) {
    return "";
  }

  if (
    elementId === "status" ||
    elementId === "priority" ||
    elementId === "ticket_type" ||
    elementId.startsWith("cf_")
  ) {
    return `${elementId}_options`;
  }

  return "";
}

function resolveTriggerOptionRecords(fieldName, fieldMeta) {
  return extractOptionRecords(runtimeState.triggerFieldCatalog[fieldName]).map((option) => ({
    ...option,
    submitValue: normalizeSubmitValue(fieldMeta, option.rawValue),
  }));
}

function resolveFieldCatalogOptionRecords(fieldMeta) {
  return extractOptionRecords(fieldMeta && fieldMeta.options).map((option) => ({
    ...option,
    submitValue: normalizeSubmitValue(fieldMeta, option.rawValue),
  }));
}

function mapLiveOptionsToRecords(fieldName, fieldMeta, rawOptions) {
  const liveOptions = extractOptionRecords(rawOptions);
  if (!liveOptions.length) {
    return [];
  }

  const triggerOptions = resolveTriggerOptionRecords(fieldName, fieldMeta);
  if (!triggerOptions.length) {
    return liveOptions;
  }

  return liveOptions.map((liveOption) => {
    const matched = triggerOptions.find((triggerOption) => (
      normalizeOptionComparisonValue(fieldMeta, triggerOption.label) ===
        normalizeOptionComparisonValue(fieldMeta, liveOption.label) ||
      normalizeOptionComparisonValue(fieldMeta, triggerOption.rawValue) ===
        normalizeOptionComparisonValue(fieldMeta, liveOption.rawValue) ||
      normalizeOptionComparisonValue(fieldMeta, triggerOption.label) ===
        normalizeOptionComparisonValue(fieldMeta, liveOption.rawValue) ||
      normalizeOptionComparisonValue(fieldMeta, triggerOption.rawValue) ===
        normalizeOptionComparisonValue(fieldMeta, liveOption.label)
    ));

    if (!matched) {
      return liveOption;
    }

    return {
      label: matched.label,
      uiValue: liveOption.uiValue,
      rawValue: matched.rawValue,
      submitValue: matched.submitValue,
    };
  });
}

function optionMatchesHiddenValue(fieldMeta, option, hiddenValue) {
  return optionValueCandidates(fieldMeta, option).some((candidate) => (
    candidate === normalizeOptionComparisonValue(fieldMeta, hiddenValue)
  ));
}

function optionMatchesCurrentValue(fieldMeta, option, currentValue) {
  const normalizedCurrentValue = normalizeOptionComparisonValue(fieldMeta, currentValue);
  if (normalizedCurrentValue === null || normalizedCurrentValue === "") {
    return false;
  }

  return optionValueCandidates(fieldMeta, option).some((candidate) => candidate === normalizedCurrentValue);
}

function optionValueCandidates(fieldMeta, option) {
  return [
    option && option.label,
    option && option.rawValue,
    option && option.submitValue,
    option && option.uiValue,
  ]
    .map((candidate) => normalizeOptionComparisonValue(fieldMeta, candidate))
    .filter((candidate) => candidate !== null && candidate !== "");
}

function buildOptionPayloadCandidates(fieldName, fieldMeta, options) {
  const strategies = resolveOptionPayloadStrategies(fieldName, fieldMeta);
  const payloadCandidates = [];
  const seenKeys = new Set();

  strategies.forEach((strategy) => {
    const values = (Array.isArray(options) ? options : [])
      .map((option) => strategy.pick(option))
      .filter((value) => value !== null && value !== undefined && value !== "");
    const key = serializeOptions(values);

    if (seenKeys.has(key)) {
      return;
    }

    seenKeys.add(key);
    payloadCandidates.push({
      strategy: strategy.name,
      values,
    });
  });

  return payloadCandidates.length ? payloadCandidates : [{ strategy: "submitValue", values: [] }];
}

function resolveOptionPayloadStrategies(fieldName, fieldMeta) {
  const strategies = fieldMeta && fieldMeta.element_id === "status"
    ? [
        { name: "submitValue", pick: (option) => option && option.submitValue },
        { name: "rawValue", pick: (option) => option && option.rawValue },
        { name: "uiValue", pick: (option) => option && option.uiValue },
        { name: "label", pick: (option) => option && option.label },
      ]
    : [
        { name: "submitValue", pick: (option) => option && option.submitValue },
      ];

  if (fieldMeta && fieldMeta.element_id === "status") {
    return strategies;
  }

  const preferredStrategy = runtimeState.optionPayloadPreferences[fieldName];
  if (!preferredStrategy) {
    return strategies;
  }

  const preferredIndex = strategies.findIndex((strategy) => strategy.name === preferredStrategy);
  if (preferredIndex <= 0) {
    return strategies;
  }

  const preferred = strategies[preferredIndex];
  return [preferred, ...strategies.filter((strategy) => strategy.name !== preferred.name)];
}

function normalizeSubmitValue(fieldMeta, value) {
  const elementId = fieldMeta && fieldMeta.element_id;
  const stringValue = value === null || value === undefined ? "" : String(value).trim();

  if (["status", "priority", "group", "agent", "product"].includes(elementId) && /^\d+$/.test(stringValue)) {
    return Number(stringValue);
  }

  return value;
}

function arraysMatch(left, right) {
  const leftArray = Array.isArray(left) ? left : [];
  const rightArray = Array.isArray(right) ? right : [];

  if (leftArray.length !== rightArray.length) {
    return false;
  }

  return leftArray.every(
    (item, index) => normalizeValue(item) === normalizeValue(rightArray[index])
  );
}

function shouldSkipFailedPayload(fieldName, nextOptionsKey) {
  const failedRecord = runtimeState.lastFailedOptions[fieldName];
  if (!failedRecord) {
    return false;
  }

  if (typeof failedRecord === "string") {
    return false;
  }

  if (failedRecord.key !== nextOptionsKey) {
    return false;
  }

  return Date.now() - Number(failedRecord.failedAt || 0) < FAILED_PAYLOAD_RETRY_COOLDOWN_MS;
}

function getFailedPayloadRetryAfter(fieldName) {
  const failedRecord = runtimeState.lastFailedOptions[fieldName];
  if (!failedRecord || typeof failedRecord === "string") {
    return 0;
  }

  const elapsed = Date.now() - Number(failedRecord.failedAt || 0);
  return Math.max(0, FAILED_PAYLOAD_RETRY_COOLDOWN_MS - elapsed);
}

function serializeOptions(options) {
  return JSON.stringify(Array.isArray(options) ? options : []);
}

function logStatusConsole(stage, details, fieldMeta, level) {
  if (!fieldMeta || fieldMeta.element_id !== "status") {
    return;
  }

  const method = level === "error"
    ? "error"
    : level === "warn"
      ? "warn"
      : "log";
  console[method](`${DEBUG_NAMESPACE} status:${stage}`, details);
}

function summarizeOptionsForConsole(options) {
  return (Array.isArray(options) ? options : []).map((option) => ({
    label: option && option.label,
    uiValue: option && option.uiValue,
    rawValue: option && option.rawValue,
    submitValue: option && option.submitValue,
  }));
}

function normalizeOptionComparisonValue(fieldMeta, value) {
  return normalizeFieldComparisonValue(fieldMeta && fieldMeta.element_id, value);
}

function normalizeFieldComparisonValue(fieldId, value) {
  const normalizedValue = normalizeValue(value);
  if (normalizedValue === null) {
    return null;
  }

  if (fieldId === "status") {
    return normalizedValue.replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim();
  }

  return normalizedValue;
}

function normalizeValue(value) {
  if (value === null || value === undefined) {
    return null;
  }
  return String(value).trim().toLowerCase();
}

function extractObjectValue(fieldId, source) {
  if (source === null || source === undefined) {
    return null;
  }

  if (typeof source !== "object") {
    return source;
  }

  if (source.new !== undefined && source.new !== null) {
    const nestedNewValue = extractObjectValue(fieldId, source.new);
    if (nestedNewValue !== null) {
      return nestedNewValue;
    }
  }

  const candidates = {
    status: ["status", "status_id"],
    priority: ["priority", "priority_id"],
    ticket_type: ["type", "ticket_type", "ticket_type_id"],
    group: ["group", "group_id"],
    agent: ["agent", "agent_id", "responder_id"],
    source: ["source", "source_id"],
  };

  const keys = candidates[fieldId] || [];
  for (let index = 0; index < keys.length; index += 1) {
    const key = keys[index];
    if (source[key] !== undefined && source[key] !== null) {
      const nestedValue = extractObjectValue(fieldId, source[key]);
      if (nestedValue !== null) {
        return nestedValue;
      }
    }
  }

  const genericKeys = ["name", "label", "text"];
  for (let index = 0; index < genericKeys.length; index += 1) {
    const key = genericKeys[index];
    if (source[key] !== undefined && source[key] !== null) {
      return source[key];
    }
  }

  if (source.ticket && typeof source.ticket === "object") {
    return extractObjectValue(fieldId, source.ticket);
  }

  if (source.value !== undefined && source.value !== null) {
    const nestedValue = extractObjectValue(fieldId, source.value);
    if (nestedValue !== null) {
      return nestedValue;
    }
  }

  if (source.id !== undefined && source.id !== null) {
    return source.id;
  }

  return null;
}

function normalizeTriggerValue(fieldId, value) {
  const normalized = normalizeFieldComparisonValue(fieldId, value);
  if (normalized === null || normalized === "") {
    return normalized;
  }

  const options = runtimeState.triggerFieldCatalog[fieldId] || [];
  const matched = options.find((option) => {
    const optionValue = normalizeFieldComparisonValue(fieldId, option && option.value);
    const optionLabel = normalizeFieldComparisonValue(fieldId, option && option.label);
    return optionValue === normalized || optionLabel === normalized;
  });

  if (matched) {
    return normalizeValue(matched.value);
  }

  return normalized;
}

function parseInvokeResponse(result) {
  if (!result) {
    return null;
  }

  if (typeof result === "string") {
    try {
      return JSON.parse(result);
    } catch {
      return null;
    }
  }

  if (typeof result.response === "string") {
    try {
      return JSON.parse(result.response);
    } catch {
      return null;
    }
  }

  if (result.response && typeof result.response === "object") {
    return result.response;
  }

  return typeof result === "object" ? result : null;
}

function resolveInvokeError(payload) {
  if (!payload) {
    return "";
  }
  return payload.message || payload.detail || (payload.error && payload.error.message) || "";
}

function isDebugEnabled() {
  try {
    return (
      localStorage.getItem(DEBUG_STORAGE_KEY) === "1" ||
      window.location.search.includes(`${DEBUG_STORAGE_KEY}=1`)
    );
  } catch {
    return false;
  }
}

function debugLog(eventName, details) {
  if (!isDebugEnabled()) {
    return;
  }

  const entry = {
    time: new Date().toISOString(),
    event: eventName,
    details: details || {},
  };

  try {
    if (!window.__DHP_DEBUG__) {
      window.__DHP_DEBUG__ = [];
    }
    window.__DHP_DEBUG__.push(entry);
    if (window.__DHP_DEBUG__.length > DEBUG_HISTORY_LIMIT) {
      window.__DHP_DEBUG__.shift();
    }
  } catch {
    // Ignore debug history failures.
  }

  if (details === undefined) {
    console.log(DEBUG_NAMESPACE, eventName);
    return;
  }

  console.log(DEBUG_NAMESPACE, eventName, details);
}
