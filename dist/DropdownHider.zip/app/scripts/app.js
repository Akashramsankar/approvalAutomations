let client;
const DASHBOARD_AUTO_RETRY_DELAY_MS = 1800;
const INVOKE_TIMEOUT_MS = 15000;

const state = {
  loading: true,
  saving: false,
  dashboardRequestId: 0,
  dashboardLoadInFlight: false,
  dashboardLoadQueued: false,
  dashboardQueuedSilent: true,
  dashboardRetryTimer: null,
  rules: [],
  fields: {
    standard: [],
    dependent: [],
  },
  triggerFields: [],
  deleteModal: {
    open: false,
    ruleId: "",
    deleting: false,
    error: "",
  },
  modal: {
    open: false,
    mode: "create",
    draft: createEmptyDraft(),
    error: "",
  },
};

document.addEventListener("DOMContentLoaded", init);

async function init() {
  try {
    client = await app.initialized();
    client.events.on("app.activated", () => loadDashboard({ silent: true }));

    bindStaticEvents();
    await loadDashboard();
  } catch (error) {
    console.error("Failed to initialize Dropdown Hider Pro dashboard:", error);
    showDashboardError("Unable to initialize Dropdown Hider Pro.");
  }
}

function bindStaticEvents() {
  document.getElementById("refreshBtn").addEventListener("click", () => loadDashboard());
  document.getElementById("createRuleBtn").addEventListener("click", () => {
    openModal("create", createEmptyDraft());
  });
  document.getElementById("cancelRuleBtn").addEventListener("click", closeModal);
  document.getElementById("saveRuleBtn").addEventListener("click", saveRule);
  document.getElementById("cancelDeleteBtn").addEventListener("click", closeDeleteModal);
  document.getElementById("confirmDeleteBtn").addEventListener("click", confirmDeleteRule);
  document.getElementById("ruleModal").addEventListener("click", (event) => {
    if (event.target.id === "ruleModal") {
      closeModal();
    }
  });
  document.getElementById("deleteModal").addEventListener("click", (event) => {
    if (event.target.id === "deleteModal") {
      closeDeleteModal();
    }
  });
}

function createEmptyDraft(kind) {
  return {
    id: "",
    name: "",
    active: true,
    kind: kind === "dependent" ? "dependent" : "standard",
    conditionOperator: "and",
    targetRootName: "",
    standardHiddenValues: [],
    dependentHiddenValues: {},
    conditions: [],
  };
}

async function loadDashboard(options) {
  const silent = Boolean(options && options.silent);
  const retryAttempt = Number((options && options.retryAttempt) || 0);
  const isAutoRetry = Boolean(options && options.isAutoRetry);

  if (!isAutoRetry) {
    clearDashboardRetry();
  }

  if (state.dashboardLoadInFlight) {
    state.dashboardLoadQueued = true;
    state.dashboardQueuedSilent = state.dashboardQueuedSilent && silent;

    if (!silent) {
      state.loading = true;
      renderDashboard();
    }
    return;
  }

  state.dashboardLoadInFlight = true;
  let nextSilent = silent;

  try {
    do {
      state.dashboardLoadQueued = false;
      state.dashboardQueuedSilent = true;
      await performDashboardLoad({ silent: nextSilent, retryAttempt });
      nextSilent = state.dashboardQueuedSilent;
    } while (state.dashboardLoadQueued);
  } finally {
    state.dashboardLoadInFlight = false;
  }
}

async function performDashboardLoad(options) {
  const silent = Boolean(options && options.silent);
  const retryAttempt = Number((options && options.retryAttempt) || 0);
  const requestId = state.dashboardRequestId + 1;
  let shouldRetry = false;
  state.dashboardRequestId = requestId;

  if (!silent) {
    state.loading = true;
    renderDashboard();
  }

  clearDashboardError();

  try {
    const response = await invokeWithTimeout("getDropdownHiderDashboardData", {});
    const payload = parseInvokeResponse(response);

    if (!payload || payload.success === false) {
      throw new Error(resolveInvokeError(payload) || "Unable to load dashboard data.");
    }

    if (requestId !== state.dashboardRequestId) {
      return;
    }

    state.fields.standard = Array.isArray(payload.fields && payload.fields.standard)
      ? payload.fields.standard
      : [];
    state.fields.dependent = Array.isArray(payload.fields && payload.fields.dependent)
      ? payload.fields.dependent
      : [];
    state.triggerFields = Array.isArray(payload.trigger_fields) ? payload.trigger_fields : [];
    state.rules = Array.isArray(payload.rules) ? payload.rules : [];
    if (!state.rules.some((rule) => rule.id === state.deleteModal.ruleId)) {
      state.deleteModal = {
        open: false,
        ruleId: "",
        deleting: false,
        error: "",
      };
    }

    if (!state.fields.standard.length && !state.fields.dependent.length) {
      showDashboardError(
        "No dropdown fields were returned by Freshdesk. Verify the app settings, then refresh the dashboard."
      );
      shouldRetry = retryAttempt < 1;
    } else {
      clearDashboardRetry();
    }
  } catch (error) {
    if (requestId !== state.dashboardRequestId) {
      return;
    }

    console.error("Failed to load dashboard data:", error);
    showDashboardError(resolveErrorMessage(error, "Unable to load dashboard data."));
    shouldRetry = retryAttempt < 1;
  } finally {
    if (requestId === state.dashboardRequestId) {
      state.loading = false;
      renderDashboard();

      if (shouldRetry && !state.dashboardLoadQueued) {
        scheduleDashboardRetry({
          requestId,
          silent,
          retryAttempt: retryAttempt + 1,
        });
      }
    }
  }
}

function scheduleDashboardRetry(options) {
  const requestId = Number(options && options.requestId);
  if (!requestId || requestId !== state.dashboardRequestId) {
    return;
  }

  clearDashboardRetry();
  state.dashboardRetryTimer = window.setTimeout(() => {
    state.dashboardRetryTimer = null;
    if (requestId !== state.dashboardRequestId) {
      return;
    }

    void loadDashboard({
      silent: Boolean(options && options.silent),
      retryAttempt: Number((options && options.retryAttempt) || 1),
      isAutoRetry: true,
    });
  }, DASHBOARD_AUTO_RETRY_DELAY_MS);
}

function clearDashboardRetry() {
  if (state.dashboardRetryTimer) {
    window.clearTimeout(state.dashboardRetryTimer);
    state.dashboardRetryTimer = null;
  }
}

function renderDashboard() {
  renderRules();
  renderModal();
  renderDeleteModal();
  updateTopButtons();
}

function renderRules() {
  const loadingState = document.getElementById("loadingState");
  const emptyState = document.getElementById("emptyState");
  const ruleList = document.getElementById("ruleList");

  if (state.loading) {
    loadingState.classList.remove("hidden");
    emptyState.classList.add("hidden");
    ruleList.classList.add("hidden");
    ruleList.innerHTML = "";
    return;
  }

  loadingState.classList.add("hidden");

  if (!state.rules.length) {
    emptyState.classList.remove("hidden");
    ruleList.classList.add("hidden");
    ruleList.innerHTML = "";
    return;
  }

  emptyState.classList.add("hidden");
  ruleList.classList.remove("hidden");

  ruleList.innerHTML = state.rules
    .map((rule) => {
      const hiddenSummary = formatHiddenSummary(rule);
      const triggerSummary = formatConditionSummary(rule.conditions, rule.condition_operator);

      return `
        <article class="rule-card">
          <div class="rule-top">
            <div>
              <h3 class="rule-title">${escapeHtml(rule.name)}</h3>
              <div class="rule-meta">
                <span class="pill">${escapeHtml(rule.kind === "dependent" ? "Dependent" : "Standard")}</span>
                <span class="pill pill-muted">${escapeHtml(rule.target_root_label || "Unknown field")}</span>
                <span class="pill ${rule.active !== false ? "pill-success" : "pill-muted"}">${escapeHtml(rule.active !== false ? "Active" : "Paused")}</span>
              </div>
            </div>
            <div class="helper">Updated ${escapeHtml(formatDateTime(rule.updated_at))}</div>
          </div>

          <div class="rule-body">
            <section class="rule-section">
              <strong>What Gets Hidden</strong>
              <p>${escapeHtml(hiddenSummary)}</p>
            </section>
            <section class="rule-section">
              <strong>When It Runs</strong>
              <p>${escapeHtml(triggerSummary)}</p>
            </section>
            <section class="rule-section">
              <strong>Coverage</strong>
              <p>Applied on the new-ticket page and the ticket details page through the background runtime.</p>
            </section>
          </div>

          <div class="rule-actions">
            <button class="btn btn-secondary" type="button" data-action="edit-rule" data-id="${escapeHtml(rule.id)}">Edit</button>
            <button class="btn ${rule.active !== false ? "btn-secondary" : "btn-primary"}" type="button" data-action="toggle-rule" data-id="${escapeHtml(rule.id)}">${rule.active !== false ? "Pause Rule" : "Enable Rule"}</button>
            <button class="btn btn-danger" type="button" data-action="delete-rule" data-id="${escapeHtml(rule.id)}">Delete</button>
          </div>
        </article>
      `;
    })
    .join("");

  ruleList.querySelectorAll("[data-action]").forEach((button) => {
    button.addEventListener("click", handleRuleAction);
  });
}

function handleRuleAction(event) {
  const action = event.currentTarget.getAttribute("data-action");
  const ruleId = event.currentTarget.getAttribute("data-id");
  const rule = state.rules.find((item) => item.id === ruleId);

  if (!rule) {
    return;
  }

  if (action === "edit-rule") {
    openModal("edit", createDraftFromRule(rule));
    return;
  }

  if (action === "toggle-rule") {
    toggleRule(rule);
    return;
  }

  if (action === "delete-rule") {
    openDeleteModal(rule.id);
  }
}

function openModal(mode, draft) {
  if (draft.kind === "standard" && !state.fields.standard.length && state.fields.dependent.length) {
    draft.kind = "dependent";
  }

  if (draft.kind === "dependent" && !state.fields.dependent.length && state.fields.standard.length) {
    draft.kind = "standard";
  }

  state.modal.open = true;
  state.modal.mode = mode;
  state.modal.error = "";
  state.modal.draft = draft;

  renderModal();
}

function closeModal() {
  if (state.saving) {
    return;
  }

  state.modal.open = false;
  state.modal.error = "";
  renderModal();
}

function openDeleteModal(ruleId) {
  state.deleteModal.open = true;
  state.deleteModal.ruleId = ruleId;
  state.deleteModal.deleting = false;
  state.deleteModal.error = "";
  renderDeleteModal();
}

function closeDeleteModal() {
  if (state.deleteModal.deleting) {
    return;
  }

  state.deleteModal.open = false;
  state.deleteModal.ruleId = "";
  state.deleteModal.error = "";
  renderDeleteModal();
}

function createDraftFromRule(rule) {
  const dependentHiddenValues = {};
  (rule.hidden_selections || []).forEach((selection) => {
    dependentHiddenValues[selection.field_name] = Array.isArray(selection.hidden_values)
      ? [...selection.hidden_values]
      : [];
  });

  return {
    id: rule.id,
    name: rule.name || "",
    active: rule.active !== false,
    kind: rule.kind === "dependent" ? "dependent" : "standard",
    conditionOperator: normalizeConditionOperator(rule.condition_operator),
    targetRootName: rule.target_root_name || "",
    standardHiddenValues:
      rule.kind === "standard" && rule.hidden_selections && rule.hidden_selections[0]
        ? [...(rule.hidden_selections[0].hidden_values || [])]
        : [],
    dependentHiddenValues,
    conditions: (rule.conditions || []).map((condition) => ({
      field: condition.field,
      values: [...(condition.values || [])],
    })),
  };
}

function renderModal() {
  const modal = document.getElementById("ruleModal");
  const modalContent = document.getElementById("modalContent");
  const modalTitle = document.getElementById("modalTitle");
  const modalError = document.getElementById("modalError");
  const saveBtn = document.getElementById("saveRuleBtn");

  modal.classList.toggle("visible", state.modal.open);
  modal.setAttribute("aria-hidden", state.modal.open ? "false" : "true");
  document.body.classList.toggle("rule-modal-open", state.modal.open || state.deleteModal.open);

  if (!state.modal.open) {
    modalContent.innerHTML = "";
    modalError.classList.add("hidden");
    saveBtn.disabled = false;
    saveBtn.textContent = "Save Rule";
    return;
  }

  modalTitle.textContent = state.modal.mode === "edit" ? "Edit Rule" : "Create Rule";
  saveBtn.disabled = state.saving;
  saveBtn.innerHTML = state.saving ? '<span class="spinner"></span>Saving' : "Save Rule";

  if (state.modal.error) {
    modalError.textContent = state.modal.error;
    modalError.classList.remove("hidden");
  } else {
    modalError.textContent = "";
    modalError.classList.add("hidden");
  }

  const draft = state.modal.draft;
  const currentStandardField = getSelectedStandardField(draft);
  const currentDependentField = getSelectedDependentField(draft);
  const noFieldsLoaded = !state.fields.standard.length && !state.fields.dependent.length;

  modalContent.innerHTML = `
    <div class="draft-grid">
      <div class="card">
        <h4>Rule Setup</h4>
        <p class="card-copy">Start with the field category, then choose the exact values that should disappear for agents.</p>

        ${
          noFieldsLoaded
            ? `
              <div class="error-banner">
                No dropdown fields are available yet. Verify the app settings and refresh the dashboard so the field list can be loaded from Freshdesk.
              </div>
            `
            : ""
        }

        <div class="field-grid">
          <div class="field field-wide">
            <label for="ruleNameInput">Rule name</label>
            <input id="ruleNameInput" class="input" type="text" value="${escapeAttribute(draft.name)}" placeholder="Example: Hide retired plan values">
          </div>
        </div>

        <div class="tabs">
          <button class="tab ${draft.kind === "standard" ? "active" : ""}" type="button" data-tab="standard">Standard Dropdown</button>
          <button class="tab ${draft.kind === "dependent" ? "active" : ""}" type="button" data-tab="dependent">Dependent Dropdown</button>
        </div>

        ${draft.kind === "standard" ? renderStandardTab(draft, currentStandardField) : renderDependentTab(draft, currentDependentField)}

        <label class="toggle-row">
          <input id="ruleActiveInput" type="checkbox" ${draft.active ? "checked" : ""}>
          <span>Keep this rule active immediately after saving</span>
        </label>
      </div>

      <div class="card">
        <h4>Automation</h4>
        <p class="card-copy">Add one or more conditions using Status, Priority, Type, Group, or Agent if the hiding should only happen in specific contexts.</p>

        <div class="logic-panel">
          <div>
            <strong class="logic-title">Condition Matching</strong>
            <p class="logic-copy">Choose whether all trigger conditions must match or whether any single matching condition should run the rule.</p>
          </div>
          <div class="logic-toggle" role="group" aria-label="Condition matching">
            <button class="logic-option ${draft.conditionOperator === "and" ? "active" : ""}" type="button" data-condition-operator="and">All Must Match</button>
            <button class="logic-option ${draft.conditionOperator === "or" ? "active" : ""}" type="button" data-condition-operator="or">Any Can Match</button>
          </div>
        </div>

        <div class="condition-list">
          ${renderConditionCards(draft.conditions)}
        </div>

        <div style="margin-top:14px;">
          <button class="btn btn-secondary" id="addConditionBtn" type="button">Add Trigger Condition</button>
        </div>

        <div class="summary-list">
          <div class="summary-item">
            <strong>Target Field</strong>
            <p>${escapeHtml(resolveDraftTargetLabel(draft) || "Choose a field to continue.")}</p>
          </div>
          <div class="summary-item">
            <strong>Hidden Values</strong>
            <p>${escapeHtml(resolveDraftHiddenSummary(draft))}</p>
          </div>
          <div class="summary-item">
            <strong>Rule Activation</strong>
            <p>${escapeHtml(draft.conditions.length ? formatConditionSummary(draft.conditions, draft.conditionOperator) : "Always on unless you pause it.")}</p>
          </div>
        </div>
      </div>
    </div>
  `;

  bindModalEvents();
}

function renderDeleteModal() {
  const modal = document.getElementById("deleteModal");
  const text = document.getElementById("deleteModalText");
  const error = document.getElementById("deleteModalError");
  const confirmButton = document.getElementById("confirmDeleteBtn");
  const cancelButton = document.getElementById("cancelDeleteBtn");
  const rule = state.rules.find((item) => item.id === state.deleteModal.ruleId);

  modal.classList.toggle("visible", state.deleteModal.open);
  modal.setAttribute("aria-hidden", state.deleteModal.open ? "false" : "true");
  document.body.classList.toggle("rule-modal-open", state.modal.open || state.deleteModal.open);

  if (!state.deleteModal.open) {
    error.classList.add("hidden");
    error.textContent = "";
    confirmButton.disabled = false;
    confirmButton.textContent = "Delete Rule";
    cancelButton.disabled = false;
    return;
  }

  text.textContent = rule
    ? rule.name
    : "Selected rule";

  if (state.deleteModal.error) {
    error.textContent = state.deleteModal.error;
    error.classList.remove("hidden");
  } else {
    error.textContent = "";
    error.classList.add("hidden");
  }

  confirmButton.disabled = state.deleteModal.deleting;
  confirmButton.innerHTML = state.deleteModal.deleting
    ? '<span class="spinner"></span>Deleting'
    : "Delete Rule";
  cancelButton.disabled = state.deleteModal.deleting;
}

function renderStandardTab(draft, field) {
  if (!state.fields.standard.length) {
    return `
      <div class="option-panel-grid">
        <section class="option-panel">
          <div class="helper">No standard dropdown fields were found for this account.</div>
        </section>
      </div>
    `;
  }

  const options = field ? field.options || [] : [];

  return `
    <div class="field-grid" style="margin-top:18px;">
      <div class="field field-wide">
        <label for="standardFieldSelect">Field</label>
        <select id="standardFieldSelect" class="select">
          <option value="">Select a field</option>
          ${state.fields.standard
            .map(
              (item) => `
                <option value="${escapeAttribute(item.name)}" ${item.name === draft.targetRootName ? "selected" : ""}>${escapeHtml(item.label)}</option>
              `
            )
            .join("")}
        </select>
        <div class="helper">Choose any ticket dropdown field to decide which values should be hidden.</div>
      </div>
    </div>

    <div class="option-panel-grid">
      <section class="option-panel">
        <h5>Values To Hide</h5>
        <div class="helper">Select one or many dropdown values to hide from the chosen field.</div>
        ${
          field
            ? renderValueCheckboxes("standard", field.name, options, draft.standardHiddenValues)
            : '<div class="helper" style="margin-top:12px;">Select a field first to load its values.</div>'
        }
      </section>
    </div>
  `;
}

function renderDependentTab(draft, field) {
  if (!state.fields.dependent.length) {
    return `
      <div class="option-panel-grid">
        <section class="option-panel">
          <div class="helper">No dependent dropdown fields were found for this account.</div>
        </section>
      </div>
    `;
  }

  const levels = field ? field.levels || [] : [];

  return `
    <div class="field-grid" style="margin-top:18px;">
      <div class="field field-wide">
        <label for="dependentFieldSelect">Field</label>
        <select id="dependentFieldSelect" class="select">
          <option value="">Select a field</option>
          ${state.fields.dependent
            .map(
              (item) => `
                <option value="${escapeAttribute(item.name)}" ${item.name === draft.targetRootName ? "selected" : ""}>${escapeHtml(item.label)}</option>
              `
            )
            .join("")}
        </select>
        <div class="helper">Choose the parent dependent field, then hide values across any level in the hierarchy.</div>
      </div>
    </div>

    <div class="option-panel-grid">
      ${
        field
          ? levels
              .map((level, index) => {
                const heading = index === 0 ? "Values" : index === 1 ? "Dependent Values" : index === 2 ? "Subdependent Values" : `Level ${index + 1} Values`;
                const selectedValues = draft.dependentHiddenValues[level.name] || [];

                return `
                  <section class="option-panel">
                    <h5>${escapeHtml(heading)}</h5>
                    <div class="helper">${escapeHtml(level.label)}</div>
                    ${renderValueCheckboxes("dependent", level.name, level.options || [], selectedValues)}
                  </section>
                `;
              })
              .join("")
          : '<section class="option-panel"><div class="helper">Select a field first to load its dependent values.</div></section>'
      }
    </div>
  `;
}

function renderValueCheckboxes(mode, fieldName, options, selectedValues) {
  if (!options.length) {
    return '<div class="helper" style="margin-top:12px;">No values are available for this field yet.</div>';
  }

  const selectedSet = new Set((selectedValues || []).map(normalizeString));

  return `
    <div class="checkbox-grid">
      ${options
        .map((option) => {
          const optionValue = getOptionValue(option);
          const optionLabel = getOptionLabel(option);
          const checked = selectedSet.has(normalizeString(optionValue));
          return `
            <label class="checkbox-card">
              <input type="checkbox" data-mode="${escapeAttribute(mode)}" data-field-name="${escapeAttribute(fieldName)}" data-value="${escapeAttribute(optionValue)}" ${checked ? "checked" : ""}>
              <span>${escapeHtml(optionLabel)}</span>
            </label>
          `;
        })
        .join("")}
    </div>
  `;
}

function renderConditionCards(conditions) {
  if (!conditions.length) {
    return '<div class="helper">No trigger conditions yet. The rule will stay active at all times.</div>';
  }

  return conditions
    .map((condition, index) => {
      const field = state.triggerFields.find((item) => item.id === condition.field) || null;
      const availableValues = Array.isArray(field && field.options) ? field.options : [];

      return `
        <section class="condition-card">
          <div class="field-grid" style="margin-top:0;">
            <div class="field">
              <label>Trigger Field</label>
              <select class="select condition-field-select" data-index="${index}">
                <option value="">Select a field</option>
                ${state.triggerFields
                  .map(
                    (item) => `
                      <option value="${escapeAttribute(item.id)}" ${item.id === (field && field.id) ? "selected" : ""}>${escapeHtml(item.label)}</option>
                    `
                  )
                  .join("")}
              </select>
            </div>
            <div class="field">
              <label>Run When Value Is</label>
              <select class="select condition-values-select" data-index="${index}">
                <option value="">Select a value</option>
                ${availableValues
                  .map((option) => {
                    const selected = (condition.values || [])[0] === option.value;
                    return `
                      <option value="${escapeAttribute(option.value)}" ${selected ? "selected" : ""}>${escapeHtml(option.label)}</option>
                    `;
                  })
                  .join("")}
              </select>
            </div>
          </div>
          <div class="condition-actions">
            <button class="btn btn-danger remove-condition-btn" type="button" data-index="${index}">Remove</button>
          </div>
        </section>
      `;
    })
    .join("");
}

function bindModalEvents() {
  const ruleNameInput = document.getElementById("ruleNameInput");
  const ruleActiveInput = document.getElementById("ruleActiveInput");
  const standardFieldSelect = document.getElementById("standardFieldSelect");
  const dependentFieldSelect = document.getElementById("dependentFieldSelect");
  const addConditionBtn = document.getElementById("addConditionBtn");

  if (ruleNameInput) {
    ruleNameInput.addEventListener("input", (event) => {
      state.modal.draft.name = event.target.value;
    });
  }

  if (ruleActiveInput) {
    ruleActiveInput.addEventListener("change", (event) => {
      state.modal.draft.active = Boolean(event.target.checked);
    });
  }

  document.querySelectorAll("[data-tab]").forEach((button) => {
    button.addEventListener("click", () => switchDraftKind(button.getAttribute("data-tab")));
  });

  document.querySelectorAll("[data-condition-operator]").forEach((button) => {
    button.addEventListener("click", () => {
      state.modal.draft.conditionOperator = normalizeConditionOperator(
        button.getAttribute("data-condition-operator")
      );
      renderModal();
    });
  });

  if (standardFieldSelect) {
    standardFieldSelect.addEventListener("change", (event) => {
      state.modal.draft.targetRootName = event.target.value;
      state.modal.draft.standardHiddenValues = [];
      renderModal();
    });
  }

  if (dependentFieldSelect) {
    dependentFieldSelect.addEventListener("change", (event) => {
      state.modal.draft.targetRootName = event.target.value;
      state.modal.draft.dependentHiddenValues = {};
      renderModal();
    });
  }

  document.querySelectorAll(".checkbox-card input[type='checkbox']").forEach((checkbox) => {
    checkbox.addEventListener("change", handleValueCheckboxChange);
  });

  document.querySelectorAll(".condition-field-select").forEach((select) => {
    select.addEventListener("change", handleConditionFieldChange);
  });

  document.querySelectorAll(".condition-values-select").forEach((select) => {
    select.addEventListener("change", handleConditionValuesChange);
  });

  document.querySelectorAll(".remove-condition-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const index = Number(button.getAttribute("data-index"));
      state.modal.draft.conditions.splice(index, 1);
      renderModal();
    });
  });

  if (addConditionBtn) {
    addConditionBtn.addEventListener("click", () => {
      state.modal.draft.conditions.push({
        field: "",
        values: [],
      });
      renderModal();
    });
  }
}

function switchDraftKind(kind) {
  const nextDraft = createEmptyDraft(kind);
  nextDraft.id = state.modal.draft.id;
  nextDraft.name = state.modal.draft.name;
  nextDraft.active = state.modal.draft.active;
  nextDraft.conditionOperator = normalizeConditionOperator(state.modal.draft.conditionOperator);
  nextDraft.conditions = [...state.modal.draft.conditions];
  state.modal.draft = nextDraft;
  renderModal();
}

function handleValueCheckboxChange(event) {
  const checkbox = event.target;
  const mode = checkbox.getAttribute("data-mode");
  const fieldName = checkbox.getAttribute("data-field-name");
  const value = checkbox.getAttribute("data-value");

  if (mode === "standard") {
    updateStringSelection(state.modal.draft.standardHiddenValues, value, checkbox.checked);
  } else {
    if (!state.modal.draft.dependentHiddenValues[fieldName]) {
      state.modal.draft.dependentHiddenValues[fieldName] = [];
    }
    updateStringSelection(state.modal.draft.dependentHiddenValues[fieldName], value, checkbox.checked);
  }

  renderModal();
}

function handleConditionFieldChange(event) {
  const index = Number(event.target.getAttribute("data-index"));
  state.modal.draft.conditions[index] = {
    field: event.target.value,
    values: [],
  };
  renderModal();
}

function handleConditionValuesChange(event) {
  const index = Number(event.target.getAttribute("data-index"));
  state.modal.draft.conditions[index].values = event.target.value ? [event.target.value] : [];
}

function updateStringSelection(list, value, shouldInclude) {
  const normalized = normalizeString(value);
  const currentIndex = list.findIndex((item) => normalizeString(item) === normalized);

  if (shouldInclude && currentIndex === -1) {
    list.push(value);
  }

  if (!shouldInclude && currentIndex !== -1) {
    list.splice(currentIndex, 1);
  }
}

async function saveRule() {
  if (state.saving) {
    return;
  }

  if (hasIncompleteConditions(state.modal.draft.conditions)) {
    state.modal.error = "Complete or remove every trigger condition before saving.";
    renderModal();
    return;
  }

  const payload = serializeDraft(state.modal.draft);
  const validationMessage = validateDraft(payload);
  if (validationMessage) {
    state.modal.error = validationMessage;
    renderModal();
    return;
  }

  state.saving = true;
  state.modal.error = "";
  renderModal();

  try {
    const response = await invokeWithTimeout("saveDropdownHiderRule", payload);
    const result = parseInvokeResponse(response);

    if (!result || result.success === false) {
      throw new Error(resolveInvokeError(result) || "Unable to save the rule.");
    }

    notify("success", "Rule saved successfully.");
    state.modal.open = false;
    state.modal.error = "";
    await loadDashboard({ silent: true });
  } catch (error) {
    console.error("Failed to save rule:", error);
    state.modal.error = resolveErrorMessage(error, "Unable to save the rule.");
    renderModal();
  } finally {
    state.saving = false;
    renderModal();
  }
}

async function toggleRule(rule) {
  const draft = createDraftFromRule(rule);
  draft.active = !rule.active;

  try {
    const response = await invokeWithTimeout("saveDropdownHiderRule", serializeDraft(draft));
    const result = parseInvokeResponse(response);

    if (!result || result.success === false) {
      throw new Error(resolveInvokeError(result) || "Unable to update the rule.");
    }

    notify("success", rule.active !== false ? "Rule paused." : "Rule enabled.");
    await loadDashboard({ silent: true });
  } catch (error) {
    console.error("Failed to toggle rule:", error);
    notify("error", resolveErrorMessage(error, "Unable to update the rule."));
  }
}

async function deleteRule(rule) {
  try {
    const response = await invokeWithTimeout("deleteDropdownHiderRule", {
      id: rule.id,
    });
    const result = parseInvokeResponse(response);

    if (!result || result.success === false) {
      throw new Error(resolveInvokeError(result) || "Unable to delete the rule.");
    }

    notify("success", "Rule deleted.");
    await loadDashboard({ silent: true });
  } catch (error) {
    console.error("Failed to delete rule:", error);
    throw error;
  }
}

async function confirmDeleteRule() {
  if (state.deleteModal.deleting) {
    return;
  }

  const rule = state.rules.find((item) => item.id === state.deleteModal.ruleId);
  if (!rule) {
    state.deleteModal.error = "The selected rule could not be found.";
    renderDeleteModal();
    return;
  }

  state.deleteModal.deleting = true;
  state.deleteModal.error = "";
  renderDeleteModal();

  try {
    await deleteRule(rule);
    state.deleteModal.open = false;
    state.deleteModal.ruleId = "";
  } catch (error) {
    state.deleteModal.error = resolveErrorMessage(error, "Unable to delete the rule.");
  } finally {
    state.deleteModal.deleting = false;
    renderDeleteModal();
  }
}

function serializeDraft(draft) {
  const payload = {
    id: draft.id || "",
    name: draft.name,
    kind: draft.kind,
    active: draft.active !== false,
    condition_operator: normalizeConditionOperator(draft.conditionOperator),
    target_root_name: draft.targetRootName,
    hidden_selections: [],
    conditions: (draft.conditions || [])
      .map((condition) => ({
        field: condition.field,
        values: Array.isArray(condition.values) ? condition.values : [],
      }))
      .filter((condition) => condition.field && condition.values.length),
  };

  if (draft.kind === "standard") {
    payload.hidden_selections = draft.standardHiddenValues.length
      ? [
          {
            field_name: draft.targetRootName,
            hidden_values: draft.standardHiddenValues,
          },
        ]
      : [];
  } else {
    payload.hidden_selections = Object.keys(draft.dependentHiddenValues || {})
      .map((fieldName) => ({
        field_name: fieldName,
        hidden_values: draft.dependentHiddenValues[fieldName] || [],
      }))
      .filter((selection) => selection.hidden_values.length);
  }

  return payload;
}

function validateDraft(payload) {
  if (!payload.target_root_name) {
    return "Choose a field for this rule.";
  }

  if (!payload.hidden_selections.length) {
    return "Select at least one value to hide.";
  }

  return "";
}

function getSelectedStandardField(draft) {
  return state.fields.standard.find((field) => field.name === draft.targetRootName) || null;
}

function getSelectedDependentField(draft) {
  return state.fields.dependent.find((field) => field.name === draft.targetRootName) || null;
}

function resolveDraftTargetLabel(draft) {
  const field = draft.kind === "dependent" ? getSelectedDependentField(draft) : getSelectedStandardField(draft);
  return field ? field.label : "";
}

function resolveDraftHiddenSummary(draft) {
  if (draft.kind === "standard") {
    return draft.standardHiddenValues.length ? `${draft.standardHiddenValues.length} value(s) selected` : "No values selected yet.";
  }

  const count = Object.values(draft.dependentHiddenValues || {}).reduce(
    (total, values) => total + values.length,
    0
  );
  return count ? `${count} value(s) selected across the hierarchy` : "No values selected yet.";
}

function formatHiddenSummary(rule) {
  const selections = Array.isArray(rule.hidden_selections) ? rule.hidden_selections : [];
  if (!selections.length) {
    return "No hidden values configured.";
  }

  return selections
    .map((selection) => {
      const values = Array.isArray(selection.hidden_value_labels) && selection.hidden_value_labels.length
        ? selection.hidden_value_labels
        : (Array.isArray(selection.hidden_values) ? selection.hidden_values : []);
      return `${selection.field_label || selection.field_name}: ${values.join(", ")}`;
    })
    .join(" | ");
}

function formatConditionSummary(conditions, operator) {
  const items = Array.isArray(conditions) ? conditions : [];
  if (!items.length) {
    return "Always active";
  }

  const normalizedOperator = normalizeConditionOperator(operator);
  const parts = items
    .map((condition) => {
      const triggerField = state.triggerFields.find((item) => item.id === condition.field) || null;
      const fieldLabel = condition.label || (triggerField && triggerField.label) || condition.field;

      let values = condition.value_labels;
      if (!values || !values.length) {
        const rawValues = condition.values || [];
        if (triggerField && Array.isArray(triggerField.options)) {
          const optionMap = Object.fromEntries(
            triggerField.options.map((opt) => [String(opt.value), opt.label])
          );
          values = rawValues.map((v) => optionMap[String(v)] || v);
        } else {
          values = rawValues;
        }
      }

      return `${fieldLabel}: ${values.join(", ")}`;
    });

  if (parts.length === 1) {
    return parts[0];
  }

  const prefix = normalizedOperator === "or" ? "Any of these" : "All of these";
  const connector = normalizedOperator === "or" ? " OR " : " AND ";
  return `${prefix}: ${parts.join(connector)}`;
}

function hasIncompleteConditions(conditions) {
  return (Array.isArray(conditions) ? conditions : []).some((condition) => {
    const hasField = Boolean(condition && condition.field);
    const hasValue = Boolean(condition && Array.isArray(condition.values) && condition.values.length);
    return hasField !== hasValue;
  });
}

function normalizeConditionOperator(value) {
  return normalizeString(value) === "or" ? "or" : "and";
}

function formatDateTime(value) {
  if (!value) {
    return "-";
  }

  try {
    return new Date(value).toLocaleString(undefined, {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });
  } catch {
    return "-";
  }
}

function updateTopButtons() {
  const refreshBtn = document.getElementById("refreshBtn");
  const createRuleBtn = document.getElementById("createRuleBtn");
  refreshBtn.disabled = state.loading;
  refreshBtn.innerHTML = state.loading ? '<span class="spinner"></span>Refreshing' : "Refresh Rules";
  if (createRuleBtn) {
    createRuleBtn.disabled = state.loading;
  }
}

function notify(type, message) {
  if (!client || !client.interface) {
    if (type === "error") {
      showDashboardError(message);
    }
    return;
  }

  try {
    client.interface.trigger("showNotify", {
      type: type === "error" ? "danger" : type,
      message,
    });
  } catch {
    if (type === "error") {
      showDashboardError(message);
    }
  }
}

function parseInvokeResponse(result) {
  if (!result) {
    return null;
  }

  if (typeof result === "string") {
    try {
      return JSON.parse(result);
    } catch {
      return null;
    }
  }

  if (typeof result.response === "string") {
    try {
      return JSON.parse(result.response);
    } catch {
      return null;
    }
  }

  if (result.response && typeof result.response === "object") {
    return result.response;
  }

  return typeof result === "object" ? result : null;
}

function resolveInvokeError(payload) {
  if (!payload) {
    return "";
  }
  return payload.message || payload.detail || (payload.error && payload.error.message) || "";
}

function resolveErrorMessage(error, fallback) {
  if (error && error.message) {
    return error.message;
  }
  if (error && error.detail) {
    return error.detail;
  }
  if (typeof error === "string") {
    return error;
  }
  if (error && typeof error === "object") {
    try {
      return JSON.stringify(error);
    } catch {
      return fallback;
    }
  }
  return fallback;
}

function invokeWithTimeout(name, args, timeoutMs) {
  return new Promise(function (resolve, reject) {
    const timer = setTimeout(function () {
      reject(new Error("Request timed out. Please try again."));
    }, timeoutMs || INVOKE_TIMEOUT_MS);

    client.request.invoke(name, args).then(
      function (result) {
        clearTimeout(timer);
        resolve(result);
      },
      function (error) {
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}

function showDashboardError(message) {
  const errorEl = document.getElementById("dashboardError");
  errorEl.textContent = message;
  errorEl.classList.remove("hidden");
}

function clearDashboardError() {
  const errorEl = document.getElementById("dashboardError");
  errorEl.textContent = "";
  errorEl.classList.add("hidden");
}

function normalizeString(value) {
  return String(value || "").trim().toLowerCase();
}

function getOptionValue(option) {
  if (option && typeof option === "object") {
    return option.value !== undefined && option.value !== null ? option.value : option.label;
  }
  return option;
}

function getOptionLabel(option) {
  if (option && typeof option === "object") {
    return option.label !== undefined && option.label !== null ? option.label : option.value;
  }
  return option;
}

function escapeHtml(value) {
  const div = document.createElement("div");
  div.textContent = value === null || value === undefined ? "" : String(value);
  return div.innerHTML;
}

function escapeAttribute(value) {
  return escapeHtml(value).replace(/"/g, "&quot;");
}
