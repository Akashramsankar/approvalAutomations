const RULES_KEY = "dropdown_hider_rules_v1";
const PAGE_SIZE = 100;
const METADATA_CACHE_TTL_MS = 30000;

const metadataCache = {
  value: null,
  expiresAt: 0,
  promise: null,
};

const DEFAULT_STATUS_OPTIONS = [
  { value: "2", label: "Open" },
  { value: "3", label: "Pending" },
  { value: "4", label: "Resolved" },
  { value: "5", label: "Closed" },
];

const LEGACY_STATUS_LABELS = {
  "6": "Waiting on customer",
  "7": "Waiting on third party",
};

const DEFAULT_PRIORITY_OPTIONS = [
  { value: "1", label: "Low" },
  { value: "2", label: "Medium" },
  { value: "3", label: "High" },
  { value: "4", label: "Urgent" },
];

const DEFAULT_SOURCE_OPTIONS = [
  { value: "1", label: "Email" },
  { value: "2", label: "Portal" },
  { value: "3", label: "Phone" },
  { value: "7", label: "Chat" },
  { value: "9", label: "Feedback Widget" },
  { value: "10", label: "Outbound Email" },
];

const SYSTEM_OPTION_LABELS = {
  status: Object.fromEntries(DEFAULT_STATUS_OPTIONS.map((item) => [item.value, item.label])),
  priority: Object.fromEntries(DEFAULT_PRIORITY_OPTIONS.map((item) => [item.value, item.label])),
  source: Object.fromEntries(DEFAULT_SOURCE_OPTIONS.map((item) => [item.value, item.label])),
};

const SUPPORTED_TARGET_SYSTEM_FIELDS = new Set([
  "status",
  "priority",
  "ticket_type",
  "group",
  "agent",
  "product",
]);

function parseArgs(args) {
  if (!args) {
    return {};
  }

  if (typeof args.body === "string") {
    return JSON.parse(args.body);
  }

  if (args.body && typeof args.body === "object") {
    return args.body;
  }

  return args;
}

function normalizeText(value) {
  return String(value || "").trim();
}

function slugify(value) {
  return normalizeText(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function dedupeStrings(items) {
  const unique = [];
  const seen = new Set();

  (Array.isArray(items) ? items : []).forEach((item) => {
    const normalized = normalizeText(item);
    if (!normalized) {
      return;
    }
    const key = normalized.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(normalized);
    }
  });

  return unique;
}

function dedupeOptions(items) {
  const unique = [];
  const seen = new Set();

  (Array.isArray(items) ? items : []).forEach((item) => {
    const value = normalizeText(item && item.value);
    const label = normalizeText(item && item.label) || value;

    if (!value || !label) {
      return;
    }

    const key = `${value.toLowerCase()}::${label.toLowerCase()}`;
    if (!seen.has(key)) {
      seen.add(key);
      unique.push({ value, label });
    }
  });

  return unique;
}

function dedupeLabels(items) {
  const unique = [];
  const seen = new Set();

  (Array.isArray(items) ? items : []).forEach((item) => {
    const label = normalizeText(typeof item === "string" ? item : item && item.label);
    if (!label) {
      return;
    }

    const key = label.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(label);
    }
  });

  return unique;
}

function normalizeOptionLookupKey(fieldId, value) {
  const normalized = normalizeText(value).toLowerCase();
  if (!normalized) {
    return "";
  }

  if (normalizeText(fieldId).toLowerCase() === "status") {
    return normalized.replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim();
  }

  return normalized;
}

function isNumericToken(value) {
  return /^\d+$/.test(normalizeText(value));
}

function humanizeFieldName(value) {
  return normalizeText(value)
    .replace(/^cf_/, "")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

function buildErrorMessage(error, fallback) {
  if (!error) {
    return fallback || "Unknown error.";
  }

  const parts = [];
  if (error.status) {
    parts.push(`Status ${error.status}`);
  }
  if (error.message && error.message !== "UNKNOWN ERROR") {
    parts.push(String(error.message));
  }

  const responseText = error.response || error.responseText || error.body || "";
  if (responseText) {
    try {
      const parsed = typeof responseText === "string" ? JSON.parse(responseText) : responseText;
      parts.push(
        parsed.description ||
          parsed.message ||
          (Array.isArray(parsed.errors) ? parsed.errors.join("; ") : JSON.stringify(parsed))
      );
    } catch {
      parts.push(String(responseText));
    }
  }

  if (!parts.length) {
    parts.push(fallback || "Unknown error.");
  }

  return parts.join(" - ");
}

function buildResponse(data) {
  return renderData(null, data);
}

function buildErrorResponse(message, error) {
  return renderData({
    message,
    detail: buildErrorMessage(error, message),
    stack: error && error.stack,
  });
}

async function readDbJson(key, fallbackValue) {
  try {
    return await $db.get(key);
  } catch (error) {
    if (error && error.status === 404) {
      return fallbackValue;
    }
    throw error;
  }
}

async function writeDbJson(key, value) {
  await $db.set(key, value);
}

async function invokeRequestTemplate(name, context) {
  const response = await $request.invokeTemplate(name, {
    context: context || {},
  });

  try {
    return JSON.parse(response.response || "null");
  } catch {
    return response.response;
  }
}

async function fetchPaginated(templateName, context) {
  const items = [];

  for (let page = 1; page < 100; page += 1) {
    const pageItems = await invokeRequestTemplate(templateName, {
      ...(context || {}),
      page,
      per_page: PAGE_SIZE,
    });

    if (!Array.isArray(pageItems) || !pageItems.length) {
      break;
    }

    items.push(...pageItems);

    if (pageItems.length < PAGE_SIZE) {
      break;
    }
  }

  return items;
}

function createRuleId() {
  return `rule_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

async function readRules() {
  const stored = await readDbJson(RULES_KEY, { rules: [] });
  return Array.isArray(stored && stored.rules) ? stored.rules : [];
}

async function writeRules(rules) {
  await writeDbJson(RULES_KEY, {
    rules: Array.isArray(rules) ? rules : [],
  });
}

function maybeAddOption(bucket, item, settings) {
  if (!item || typeof item !== "object") {
    return false;
  }

  const preferIdValue = Boolean(settings && settings.preferIdValue);
  const value = normalizeText(
    (preferIdValue ? item.id || item.value : item.value || item.id) ||
      item.key ||
      item.name ||
      item.label ||
      item.display_name ||
      item.displayName ||
      item.text ||
      item.title
  );
  const label = normalizeText(
    item.label ||
      item.name ||
      item.display_name ||
      item.displayName ||
      item.text ||
      item.title ||
      item.value ||
      item.id ||
      item.key
  );

  if (!value || !label) {
    return false;
  }

  bucket.push({ value, label });
  return true;
}

function collectChoiceOptions(input, bucket, settings) {
  if (input === null || input === undefined) {
    return;
  }

  if (Array.isArray(input)) {
    input.forEach((item) => collectChoiceOptions(item, bucket, settings));
    return;
  }

  if (typeof input === "string" || typeof input === "number" || typeof input === "boolean") {
    const value = normalizeText(input);
    if (value) {
      bucket.push({ value, label: value });
    }
    return;
  }

  if (typeof input !== "object") {
    return;
  }

  if (maybeAddOption(bucket, input, settings)) {
    const nestedKeys = ["children", "choices", "options", "items", "values"];
    nestedKeys.forEach((key) => {
      if (input[key] !== undefined) {
        collectChoiceOptions(input[key], bucket, settings);
      }
    });
    return;
  }

  Object.keys(input).forEach((key) => {
    const value = input[key];
    if (
      typeof value === "string" ||
      typeof value === "number" ||
      typeof value === "boolean"
    ) {
      const rawValue = normalizeText(key);
      const rawLabel = normalizeText(value);
      if (rawValue && rawLabel) {
        bucket.push({ value: rawValue, label: rawLabel });
      }
      return;
    }

    if (Array.isArray(value)) {
      const normalizedKey = normalizeText(key);
      value.forEach((nestedItem) => {
        if (
          typeof nestedItem === "string" ||
          typeof nestedItem === "number" ||
          typeof nestedItem === "boolean"
        ) {
          const label = normalizeText(nestedItem);
          if (label) {
            bucket.push({ value: normalizedKey || label, label });
          }
        } else if (!maybeAddOption(bucket, nestedItem, settings)) {
          collectChoiceOptions(nestedItem, bucket, settings);
        }
      });
      return;
    }

    if (!maybeAddOption(bucket, value, settings)) {
      collectChoiceOptions(value, bucket, settings);
    }
  });
}

function extractChoiceOptions(input, settings) {
  const options = [];
  collectChoiceOptions(input, options, settings);
  return dedupeOptions(options);
}

function collectChoiceLabels(input, bucket) {
  if (input === null || input === undefined) {
    return;
  }

  if (Array.isArray(input)) {
    input.forEach((item) => collectChoiceLabels(item, bucket));
    return;
  }

  if (typeof input === "string" || typeof input === "number" || typeof input === "boolean") {
    const label = normalizeText(input);
    if (label) {
      bucket.push(label);
    }
    return;
  }

  if (typeof input !== "object") {
    return;
  }

  const preferredLabel = normalizeText(
    input.label ||
      input.text ||
      input.name ||
      input.display_name ||
      input.displayName ||
      input.value
  );

  if (preferredLabel) {
    bucket.push(preferredLabel);
  }

  Object.keys(input).forEach((key) => {
    const value = input[key];

    if (
      typeof value === "string" ||
      typeof value === "number" ||
      typeof value === "boolean"
    ) {
      const normalizedValue = normalizeText(value);
      const normalizedKey = normalizeText(key);

      if (normalizedValue && !preferredLabel) {
        bucket.push(normalizedValue);
      } else if (
        normalizedKey &&
        normalizedValue &&
        normalizedKey !== "id" &&
        normalizedKey !== "value"
      ) {
        bucket.push(normalizedValue);
      }
      return;
    }

    collectChoiceLabels(value, bucket);
  });
}

function extractChoiceLabels(input) {
  const labels = [];
  collectChoiceLabels(input, labels);
  return dedupeLabels(labels);
}

function resolveReadableOptionLabel(fieldId, option) {
  const labelMap = SYSTEM_OPTION_LABELS[normalizeText(fieldId)] || {};
  const reverseLabelMap = Object.fromEntries(
    Object.entries(labelMap).map(([value, label]) => [normalizeOptionLookupKey(fieldId, label), value])
  );
  const rawValue = normalizeText(option && option.value);
  const rawLabel = normalizeText(option && option.label) || rawValue;
  const normalizedRawValue = normalizeOptionLookupKey(fieldId, rawValue);
  const normalizedRawLabel = normalizeOptionLookupKey(fieldId, rawLabel);

  if (labelMap[rawValue]) {
    return labelMap[rawValue];
  }

  if (labelMap[rawLabel]) {
    return labelMap[rawLabel];
  }

  if (rawLabel && !isNumericToken(rawLabel)) {
    return rawLabel;
  }

  if (rawValue && !isNumericToken(rawValue)) {
    return rawValue;
  }

  if (reverseLabelMap[normalizedRawValue]) {
    return labelMap[reverseLabelMap[normalizedRawValue]];
  }

  if (reverseLabelMap[normalizedRawLabel]) {
    return labelMap[reverseLabelMap[normalizedRawLabel]];
  }

  return rawLabel || rawValue;
}

function resolveCanonicalOptionValue(fieldId, option) {
  const normalizedFieldId = normalizeText(fieldId);
  const labelMap = SYSTEM_OPTION_LABELS[normalizedFieldId] || {};
  const reverseLabelMap = Object.fromEntries(
    Object.entries(labelMap).map(([value, label]) => [normalizeOptionLookupKey(fieldId, label), value])
  );

  const rawValue = normalizeText(option && option.value);
  const rawLabel = normalizeText(option && option.label) || rawValue;
  const normalizedRawValue = normalizeOptionLookupKey(fieldId, rawValue);
  const normalizedRawLabel = normalizeOptionLookupKey(fieldId, rawLabel);

  if (labelMap[rawValue]) {
    return rawValue;
  }

  if (labelMap[rawLabel]) {
    return rawLabel;
  }

  if (reverseLabelMap[normalizedRawValue]) {
    return reverseLabelMap[normalizedRawValue];
  }

  if (reverseLabelMap[normalizedRawLabel]) {
    return reverseLabelMap[normalizedRawLabel];
  }

  return rawValue || rawLabel;
}

function extractChoiceDisplayLabels(fieldId, input) {
  const options = extractChoiceOptions(input);
  if (options.length) {
    return dedupeLabels(options.map((option) => resolveReadableOptionLabel(fieldId, option)));
  }

  const labelMap = SYSTEM_OPTION_LABELS[normalizeText(fieldId)] || {};
  return dedupeLabels(
    extractChoiceLabels(input).map((label) => labelMap[normalizeText(label)] || label)
  );
}

function extractChoiceDisplayOptions(fieldId, input) {
  const options = extractChoiceOptions(input);
  if (options.length) {
    return dedupeOptions(options.map((option) => ({
      value: resolveCanonicalOptionValue(fieldId, option),
      label: resolveReadableOptionLabel(fieldId, option),
    })));
  }

  return dedupeOptions(
    extractChoiceDisplayLabels(fieldId, input).map((label) => ({
      value: label,
      label,
    }))
  );
}

function isDropdownLikeField(field) {
  const type = normalizeText(field && field.type).toLowerCase();
  return (
    type.includes("dropdown") ||
    type.includes("nested") ||
    type.includes("choice") ||
    type === "custom_dropdown" ||
    type === "default_dropdown"
  );
}

function normalizeFieldNode(field, level) {
  const name = normalizeText(field && field.name);
  if (!name) {
    return null;
  }

  const children = Array.isArray(field && (field.dependentFields || field.dependent_fields))
    ? field.dependentFields || field.dependent_fields
    : [];

  return {
    id: Number(field.id),
    name,
    label:
      normalizeText(field.label || field.labelForCustomers) || humanizeFieldName(name),
    type: normalizeText(field.type || "dropdown"),
    level,
    element_id: name,
    is_default: Boolean(field._default),
    options: extractChoiceDisplayOptions(name, field.choices),
    children: children
      .map((child) => normalizeFieldNode(child, level + 1))
      .filter(Boolean),
  };
}

function flattenFieldLevels(fieldNode) {
  const levels = [];

  function visit(node) {
    if (!node) {
      return;
    }

    levels.push({
      name: node.name,
      label: node.label,
      level: node.level,
      element_id: node.element_id,
      options: node.options,
    });

    (node.children || []).forEach(visit);
  }

  visit(fieldNode);
  return levels;
}

function indexFieldsByName(roots) {
  const index = {};

  (Array.isArray(roots) ? roots : []).forEach((root) => {
    flattenFieldLevels(root).forEach((level) => {
      index[level.name] = {
        name: level.name,
        label: level.label,
        level: level.level,
        element_id: level.element_id,
        options: level.options,
        root_name: root.name,
        root_label: root.label,
      };
    });
  });

  return index;
}

function mergeFieldLists(primaryFields, secondaryFields) {
  const merged = [];
  const seen = new Set();

  [...(Array.isArray(primaryFields) ? primaryFields : []), ...(Array.isArray(secondaryFields) ? secondaryFields : [])]
    .forEach((field) => {
      const key = normalizeText(field && field.name).toLowerCase();
      if (!key || seen.has(key)) {
        return;
      }
      seen.add(key);
      merged.push(field);
    });

  return merged;
}

function isSupportedTargetField(field) {
  const name = normalizeText(field && field.name);
  return name.startsWith("cf_") || SUPPORTED_TARGET_SYSTEM_FIELDS.has(name);
}

function createSystemField(name, label, elementId, options) {
  const normalizedOptions = dedupeOptions(
    (Array.isArray(options) ? options : []).map((option) => {
      if (typeof option === "string") {
        return { value: option, label: option };
      }

      return {
        value: normalizeText(option && option.value) || normalizeText(option && option.label),
        label: normalizeText(option && option.label) || normalizeText(option && option.value),
      };
    })
  );

  if (!normalizedOptions.length) {
    return null;
  }

  return {
    id: 0,
    name,
    label,
    type: "dropdown",
    level: 1,
    element_id: elementId,
    is_default: true,
    options: normalizedOptions,
    children: [],
  };
}

function withReadableLabels(fieldId, options) {
  return dedupeOptions((Array.isArray(options) ? options : []).map((option) => {
    return {
      value: resolveCanonicalOptionValue(fieldId, option),
      label: resolveReadableOptionLabel(fieldId, option),
    };
  }));
}

function buildOptionLookup(fieldId, options) {
  const lookup = {};
  const labelMap = SYSTEM_OPTION_LABELS[normalizeText(fieldId)] || {};

  Object.keys(labelMap).forEach((value) => {
    const label = labelMap[value];
    lookup[normalizeOptionLookupKey(fieldId, value)] = {
      value: normalizeText(value),
      label,
    };
    lookup[normalizeOptionLookupKey(fieldId, label)] = {
      value: normalizeText(value),
      label,
    };
  });

  (Array.isArray(options) ? options : []).forEach((option) => {
    const rawValue = resolveCanonicalOptionValue(
      fieldId,
      typeof option === "string" ? { value: option, label: option } : option
    );
    const rawLabel = resolveReadableOptionLabel(
      fieldId,
      typeof option === "string" ? { value: option, label: option } : option
    );

    if (!rawLabel) {
      return;
    }

    const canonicalValue = rawValue || rawLabel;
    const record = {
      value: canonicalValue,
      label: rawLabel,
    };

    lookup[normalizeOptionLookupKey(fieldId, rawLabel)] = record;
    if (canonicalValue) {
      lookup[normalizeOptionLookupKey(fieldId, canonicalValue)] = record;
    }
  });

  if (normalizeText(fieldId).toLowerCase() === "status") {
    Object.entries(LEGACY_STATUS_LABELS).forEach(([legacyValue, legacyLabel]) => {
      const matchedRecord = Object.values(lookup).find((record) => (
        normalizeOptionLookupKey(fieldId, record && record.label) ===
        normalizeOptionLookupKey(fieldId, legacyLabel)
      ));

      if (!matchedRecord) {
        return;
      }

      lookup[normalizeOptionLookupKey(fieldId, legacyValue)] = matchedRecord;
    });
  }

  return lookup;
}

function normalizeValuesWithLookup(values, lookup, mode) {
  return dedupeStrings(
    (Array.isArray(values) ? values : []).map((value) => {
      const normalizedValue = normalizeText(value);
      const matched =
        lookup[normalizedValue.toLowerCase()] ||
        lookup[normalizedValue.toLowerCase().replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim()];
      if (!matched) {
        return normalizedValue;
      }

      if (mode === "label") {
        return matched.label;
      }

      return matched.value;
    })
  );
}

function normalizeFieldCollection(payload) {
  if (Array.isArray(payload)) {
    return payload;
  }

  if (payload && Array.isArray(payload.ticket_fields)) {
    return payload.ticket_fields;
  }

  if (payload && Array.isArray(payload.fields)) {
    return payload.fields;
  }

  return [];
}

async function fetchAdminTicketFields() {
  const items = [];

  for (let page = 1; page < 100; page += 1) {
    const response = await invokeRequestTemplate("list_admin_ticket_fields", {
      page,
      per_page: PAGE_SIZE,
    });
    const pageItems = normalizeFieldCollection(response);

    if (!pageItems.length) {
      break;
    }

    items.push(...pageItems);

    if (pageItems.length < PAGE_SIZE) {
      break;
    }
  }

  return items;
}

async function fetchTicketFieldMetadata() {
  let rawFields = [];

  try {
    rawFields = await fetchAdminTicketFields();
  } catch {
    rawFields = normalizeFieldCollection(await invokeRequestTemplate("list_ticket_fields", {}));
  }

  const normalizedRoots = rawFields
    .map((field) => normalizeFieldNode(field, 1))
    .filter(
      (field) =>
        field &&
        isDropdownLikeField(field) &&
        (field.options.length || (field.children || []).length)
    );

  const standardFields = normalizedRoots
    .filter((field) => !(field.children || []).length)
    .sort((left, right) => left.label.localeCompare(right.label, undefined, { sensitivity: "base" }));

  const dependentFields = normalizedRoots
    .filter((field) => (field.children || []).length)
    .sort((left, right) => left.label.localeCompare(right.label, undefined, { sensitivity: "base" }));

  const fieldCatalog = {
    ...indexFieldsByName(standardFields),
    ...indexFieldsByName(dependentFields),
  };

  return {
    standard_fields: standardFields,
    dependent_fields: dependentFields,
    field_catalog: fieldCatalog,
    admin_fields: rawFields,
  };
}

function findAdminField(adminFields, names) {
  const expected = new Set((Array.isArray(names) ? names : []).map((item) => normalizeText(item).toLowerCase()));
  return (Array.isArray(adminFields) ? adminFields : []).find((field) =>
    expected.has(normalizeText(field && field.name).toLowerCase())
  );
}

async function fetchTriggerFields(adminFields) {
  let groups = [];
  let agents = [];

  try {
    groups = await fetchPaginated("list_groups");
  } catch {
    groups = [];
  }

  try {
    agents = await fetchPaginated("list_agents");
  } catch {
    agents = [];
  }

  const typeField = findAdminField(adminFields, ["type", "ticket_type"]);
  const statusField = findAdminField(adminFields, ["status"]);
  const priorityField = findAdminField(adminFields, ["priority"]);

  let triggerFields = [
    {
      id: "status",
      label: "Status",
      options: withReadableLabels("status",
        extractChoiceOptions(statusField && statusField.choices, { preferIdValue: true }).length
          ? extractChoiceOptions(statusField.choices, { preferIdValue: true })
          : DEFAULT_STATUS_OPTIONS),
    },
    {
      id: "priority",
      label: "Priority",
      options: withReadableLabels("priority",
        extractChoiceOptions(priorityField && priorityField.choices).length
          ? extractChoiceOptions(priorityField.choices)
          : DEFAULT_PRIORITY_OPTIONS),
    },
    {
      id: "ticket_type",
      label: "Type",
      options: extractChoiceOptions(typeField && typeField.choices),
    },
    {
      id: "group",
      label: "Group",
      options: dedupeOptions(
        groups.map((group) => ({
          value: String(group.id),
          label: normalizeText(group.name) || `Group ${group.id}`,
        }))
      ),
    },
    {
      id: "agent",
      label: "Agent",
      options: dedupeOptions(
        agents
          .filter((agent) => !agent.deleted)
          .map((agent) => ({
            value: String(agent.id),
            label:
              normalizeText(agent.contact && agent.contact.name) ||
              normalizeText(agent.name) ||
              normalizeText(agent.email) ||
              `Agent ${agent.id}`,
          }))
      ),
    },
  ];

  triggerFields = triggerFields.filter((field) => field.options.length);

  const systemFields = [
    createSystemField("status", "Status", "status", triggerFields.find((field) => field.id === "status")?.options),
    createSystemField("priority", "Priority", "priority", triggerFields.find((field) => field.id === "priority")?.options),
    createSystemField("ticket_type", "Type", "ticket_type", triggerFields.find((field) => field.id === "ticket_type")?.options),
    createSystemField("group", "Group", "group", triggerFields.find((field) => field.id === "group")?.options),
    createSystemField("agent", "Agent", "agent", triggerFields.find((field) => field.id === "agent")?.options),
  ].filter(Boolean);

  return {
    trigger_fields: triggerFields,
    system_fields: systemFields,
  };
}

async function getCachedMetadataBundle() {
  const now = Date.now();
  if (metadataCache.value && metadataCache.expiresAt > now) {
    return await Promise.resolve(metadataCache.value);
  }

  if (metadataCache.promise) {
    return await metadataCache.promise;
  }

  metadataCache.promise = (async () => {
    try {
      const metadata = await fetchTicketFieldMetadata();
      const supportData = await fetchTriggerFields(metadata.admin_fields);
      const fullMetadata = augmentMetadata(metadata, supportData);
      const bundle = { metadata, supportData, fullMetadata };

      metadataCache.value = bundle;
      metadataCache.expiresAt = Date.now() + METADATA_CACHE_TTL_MS;
      return bundle;
    } catch (error) {
      if (metadataCache.value) {
        return metadataCache.value;
      }
      throw error;
    } finally {
      metadataCache.promise = null;
    }
  })();

  return await metadataCache.promise;
}

function augmentMetadata(metadata, supportData) {
  const standardFields = mergeFieldLists(
    supportData && supportData.system_fields,
    metadata && metadata.standard_fields
  ).filter(isSupportedTargetField);
  const dependentFields = Array.isArray(metadata && metadata.dependent_fields)
    ? metadata.dependent_fields
    : [];

  return {
    ...metadata,
    standard_fields: standardFields,
    dependent_fields: dependentFields,
    field_catalog: {
      ...indexFieldsByName(standardFields),
      ...indexFieldsByName(dependentFields),
    },
  };
}

function sanitizeRuleName(ruleName, fallback) {
  return normalizeText(ruleName) || fallback || "Untitled rule";
}

function sanitizeConditionOperator(value) {
  return normalizeText(value).toLowerCase() === "or" ? "or" : "and";
}

function sanitizeConditions(conditions, triggerFields) {
  const triggerFieldMap = Object.fromEntries(
    (Array.isArray(triggerFields) ? triggerFields : []).map((field) => [field.id, field])
  );

  return (Array.isArray(conditions) ? conditions : [])
    .map((condition) => {
      const field = normalizeText(condition && condition.field);
      const config = triggerFieldMap[field];
      if (!field || !config) {
        return null;
      }

      const optionLookup = buildOptionLookup(field, config.options);
      const values = normalizeValuesWithLookup(condition.values, optionLookup, "value");

      if (!values.length) {
        return null;
      }

      return {
        field,
        label: config.label,
        values,
        value_labels: values.map((value) => {
          const matched = optionLookup[normalizeText(value).toLowerCase()];
          return (matched && matched.label) || value;
        }),
      };
    })
    .filter(Boolean);
}

function sanitizeHiddenSelections(hiddenSelections, fieldCatalog) {
  return (Array.isArray(hiddenSelections) ? hiddenSelections : [])
    .map((selection) => {
      const fieldName = normalizeText(selection && selection.field_name);
      const fieldMeta = fieldCatalog[fieldName];
      if (!fieldName || !fieldMeta) {
        return null;
      }

      const optionLookup = buildOptionLookup(fieldMeta.name, fieldMeta.options);
      const hiddenValues = normalizeValuesWithLookup(selection.hidden_values, optionLookup, "value");
      if (!hiddenValues.length) {
        return null;
      }

      return {
        field_name: fieldName,
        field_label: fieldMeta.label,
        level: Number(fieldMeta.level || 1),
        hidden_values: hiddenValues,
        hidden_value_labels: hiddenValues.map((value) => {
          const matched = optionLookup[normalizeText(value).toLowerCase()];
          return (matched && matched.label) || value;
        }),
      };
    })
    .filter(Boolean);
}

function sanitizeRulePayload(payload, metadata, triggerFields, existingRule) {
  const kind = normalizeText(payload.kind || (existingRule && existingRule.kind)).toLowerCase();
  if (!["standard", "dependent"].includes(kind)) {
    throw new Error("Rule type is invalid.");
  }

  const rootName = normalizeText(payload.target_root_name || (existingRule && existingRule.target_root_name));
  if (!rootName) {
    throw new Error("A target field is required.");
  }

  const standardFieldMap = Object.fromEntries(
    (metadata.standard_fields || []).map((field) => [field.name, field])
  );
  const dependentFieldMap = Object.fromEntries(
    (metadata.dependent_fields || []).map((field) => [field.name, field])
  );

  const rootField =
    kind === "standard" ? standardFieldMap[rootName] : dependentFieldMap[rootName];

  if (!rootField) {
    throw new Error("The selected field is no longer available.");
  }

  const allowedFieldNames = new Set(flattenFieldLevels(rootField).map((field) => field.name));
  const hiddenSelections = sanitizeHiddenSelections(payload.hidden_selections, metadata.field_catalog)
    .filter((selection) => allowedFieldNames.has(selection.field_name));

  if (!hiddenSelections.length) {
    throw new Error("Select at least one value to hide.");
  }

  const conditions = sanitizeConditions(payload.conditions, triggerFields);
  const conditionOperator = sanitizeConditionOperator(
    payload.condition_operator || (existingRule && existingRule.condition_operator)
  );
  const now = Date.now();
  const fallbackName = `${rootField.label} rule`;

  return {
    id: existingRule && existingRule.id ? existingRule.id : createRuleId(),
    name: sanitizeRuleName(payload.name, fallbackName),
    kind,
    active: payload.active !== false,
    target_root_name: rootField.name,
    target_root_label: rootField.label,
    hidden_selections: hiddenSelections,
    condition_operator: conditionOperator,
    conditions,
    created_at: existingRule && existingRule.created_at ? existingRule.created_at : now,
    updated_at: now,
  };
}

function sortRules(rules) {
  return [...(Array.isArray(rules) ? rules : [])].sort(
    (left, right) => Number(right.updated_at || 0) - Number(left.updated_at || 0)
  );
}

function mapRuleForClient(rule, fieldCatalog, triggerFields) {
  return {
    id: rule.id,
    name: rule.name,
    kind: rule.kind,
    active: rule.active !== false,
    target_root_name: rule.target_root_name,
    target_root_label: rule.target_root_label,
    condition_operator: sanitizeConditionOperator(rule.condition_operator),
    hidden_selections: sanitizeHiddenSelections(rule.hidden_selections, fieldCatalog),
    conditions: sanitizeConditions(rule.conditions, triggerFields),
    created_at: rule.created_at,
    updated_at: rule.updated_at,
  };
}

function buildRuntimeRules(rules, fieldCatalog, triggerFields) {
  return sortRules(rules)
    .filter((rule) => rule.active !== false)
    .map((rule) => ({
      id: rule.id,
      name: rule.name,
      kind: rule.kind,
      active: true,
      target_root_name: rule.target_root_name,
      target_root_label: rule.target_root_label,
      condition_operator: sanitizeConditionOperator(rule.condition_operator),
      conditions: sanitizeConditions(rule.conditions, triggerFields),
      hidden_selections: sanitizeHiddenSelections(rule.hidden_selections, fieldCatalog).map((selection) => ({
        ...selection,
        element_id:
          (fieldCatalog[selection.field_name] && fieldCatalog[selection.field_name].element_id) ||
          selection.field_name,
        available_options:
          (fieldCatalog[selection.field_name] && fieldCatalog[selection.field_name].options) || [],
      })),
    }));
}

exports = {
  getDropdownHiderDashboardData: async function () {
    try {
      const [metadataBundle, rules] = await Promise.all([
        getCachedMetadataBundle(),
        readRules(),
      ]);
      const { fullMetadata, supportData } = metadataBundle;

      return buildResponse({
        success: true,
        fields: {
          standard: fullMetadata.standard_fields.map((field) => ({
            name: field.name,
            label: field.label,
            element_id: field.element_id,
            options: field.options,
          })),
          dependent: fullMetadata.dependent_fields.map((field) => ({
            name: field.name,
            label: field.label,
            element_id: field.element_id,
            levels: flattenFieldLevels(field).map((level) => ({
              name: level.name,
              label: level.label,
              level: level.level,
              element_id: level.element_id,
              options: level.options,
            })),
          })),
        },
        trigger_fields: supportData.trigger_fields,
        rules: sortRules(rules).map((rule) =>
          mapRuleForClient(rule, fullMetadata.field_catalog, supportData.trigger_fields)
        ),
        trigger_field_catalog: Object.fromEntries(
          supportData.trigger_fields.map((field) => [field.id, field.options])
        ),
      });
    } catch (error) {
      return buildErrorResponse("Failed to load Dropdown Hider Pro dashboard data.", error);
    }
  },

  saveDropdownHiderRule: async function (args) {
    try {
      const payload = parseArgs(args);
      const { fullMetadata, supportData } = await getCachedMetadataBundle();
      const rules = await readRules();
      const existingRule = rules.find((rule) => rule.id === payload.id) || null;
      const sanitizedRule = sanitizeRulePayload(
        payload,
        fullMetadata,
        supportData.trigger_fields,
        existingRule
      );

      const nextRules = [
        sanitizedRule,
        ...rules.filter((rule) => rule.id !== sanitizedRule.id),
      ];

      await writeRules(sortRules(nextRules));

      return buildResponse({
        success: true,
        rule: mapRuleForClient(sanitizedRule, fullMetadata.field_catalog, supportData.trigger_fields),
      });
    } catch (error) {
      return buildErrorResponse("Failed to save the dropdown hiding rule.", error);
    }
  },

  deleteDropdownHiderRule: async function (args) {
    try {
      const payload = parseArgs(args);
      const ruleId = normalizeText(payload.id);
      if (!ruleId) {
        throw new Error("Rule id is required.");
      }

      const rules = await readRules();
      const existingRule = rules.find((rule) => rule.id === ruleId);
      if (!existingRule) {
        throw new Error("Rule not found.");
      }

      await writeRules(rules.filter((rule) => rule.id !== ruleId));

      return buildResponse({
        success: true,
        id: ruleId,
      });
    } catch (error) {
      return buildErrorResponse("Failed to delete the dropdown hiding rule.", error);
    }
  },

  getDropdownHiderRuntimeData: async function () {
    try {
      const { fullMetadata, supportData } = await getCachedMetadataBundle();
      const rules = await readRules();

      return buildResponse({
        success: true,
        field_catalog: fullMetadata.field_catalog,
        rules: buildRuntimeRules(rules, fullMetadata.field_catalog, supportData.trigger_fields),
        trigger_field_catalog: Object.fromEntries(
          supportData.trigger_fields.map((field) => [field.id, field.options])
        ),
        runtime_version: slugify(String(Date.now())),
      });
    } catch (error) {
      return buildErrorResponse("Failed to load Dropdown Hider Pro runtime data.", error);
    }
  },
};
